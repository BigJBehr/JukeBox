#! /bin/python3
# This script edits /etc/rc.local and either adds a command to run the JukeBox.py
# script on startup or will disable it if already preasent. Will also enable if
# present and disabled.

Filename = "/etc/rc.local"

Lines = []

# modify this to replace bigj with your username
Target = 'sudo python3 /home/bigj/JukeBox.py &'

# read file lines into a list then auto close
with open(Filename, "r") as f:
  Lines = f.readlines()

for i in range(0, len(Lines)):
  if Lines[i].startswith(Target):
      print('Auto run disabled')
      Lines[i] = '#' + Target + '\n'
      break;
  elif Lines[i].startswith('#' + Target):
    Lines[i] = Target + '\n'
    print('Auto run enabled')
    break
  elif Lines[i].startswith('exit 0'):
    # not present, add it
    print('Auto run installed')
    if i > 1:
      Lines.insert(i - 1, '\ncd /home/bigj\n' + Target + '\n')
    break
# for
     
# save changes
# write everything to a new file
with open(Filename, "w") as f:
  f.writelines(Lines)

