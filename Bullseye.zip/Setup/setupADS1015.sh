sudo apt-get install build-essential python3-dev python3-smbus
sudo pip3 install adafruit_ads1x15

