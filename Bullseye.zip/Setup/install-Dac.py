#! /bin/python3
# This script edits /boot.config.txt to enable interfaces, disable audio and
# add specified DAC driver.
# You must run as sudo with DAC type; 'sudo python3 install-Dac.py PCM5102'.

# 08-01-24 - Modified to add copying of asound.conf

#  4-19-25 - Modified to get DAC type from jukebox.cfg.

import subprocess
import sys
import os
import json

#Filename = "/home/bigj/work/config.txt"
Filename = "/boot/config.txt"

Lines = []

def uncomment():
  # uncomment SPI, I2S & I2C
  # un-commenting I2C does not make it work!!
  
  global Lines
  
  count = 3
  for i in range(0, len(Lines)):
    if count > 0:
      str = Lines[i]
      if Lines[i].startswith('#dtparam=i2c_arm=on'):
        print('Uncommented I2C')
        Lines[i] = str[1:]
        count -= 1
      if Lines[i].startswith('#dtparam=i2s=on'):
        print('Uncommented I2S')
        Lines[i] = str[1:]
        count -= 1
      if Lines[i].startswith('#dtparam=spi=on'):
        print('Uncommented SPI')
        Lines[i] = str[1:]
        count -= 1
    else:
      break
#------------------------------------------------------------------------------
  
def commentout():
  #  comment out some things
  global Lines
  
  count = 3
  for i in range(0, len(Lines)):
    if count > 0:
      str = Lines[i]
      if Lines[i].startswith('dtparam=audio=on'):
        print('Commented out audio jack')
        Lines[i] = '#' + str
        count -= 1
      if Lines[i].startswith('display_auto_detect=1'):
        print('Commented out display')
        Lines[i] = '#' + str
        count -= 1
      if Lines[i].startswith('camera_auto_detect=1'):
        print('Commented out camera')
        Lines[i] = '#' + str
        count -= 1
    else:
      break
#------------------------------------------------------------------------------
      
def killHDMIaudio():
  #  comment out some things
  global Lines
  
  for i in range(0, len(Lines)):
    if Lines[i].startswith('dtoverlay=vc4-kms-v3d'):
      print('Turned off HDMI audio')
      Lines[i] = 'dtoverlay=vc4-kms-v3d,noaudio\n'
#------------------------------------------------------------------------------
  

#===== Main Program =====

Config = {
  "Remote": "HID_Remote01.txt",
  "Display": "ILI9341",
  "DAC": {"Type": "PCM5242",
          "Name": "IQaudIODAC",
         },
  "Pico": True
}

fn = 'jukebox.cfg'

# a file access error will throw an exception and switch to the default values.
if os.path.exists(fn):
  print(fn + ' exists')

  try:
    with open(fn, 'r') as fp:
      Config = json.load(fp)

  except:
    print('Unable to load configuration json file: ' + fn)
    print('Using default configuration')

else:
  print(fn + ' does not exist')
  print('Using default configuration')

print('Remote: '  + Config['Remote'])
print('Display: ' + Config['Display'])
print('DAC: '     + Config['DAC']['Type'] + ', ' + Config['DAC']['Name'])
print('Pico: '    + str(Config['Pico']))

if Config['Pico'] == False:
  print('Control for MSGEQ7')

  #===== MSGEQ7 & ADS1015 support =====
#  from ws2812 import WS2812
#  from ws2812 import LedStrip
else:
  print('Control for Pico')



# read file lines into a list then auto close
with open(Filename, "r") as f:
  Lines = f.readlines()

# enable interfaces
uncomment()

# get rid of unused/unwanted stuff
commentout()

# turn off HDMI audio
killHDMIaudio()

##if len(sys.argv) > 1:
# DAC specific installs
try:
#    dac = sys.argv[1].lower()
  
##  dac = string(Config['DAC']['Type']).lower()
  dac = Config['DAC']['Type'].lower()
  print(dac)
  
  # install the specified DAC driver  
  if dac.startswith('pcm5102'):
    print('Generic DAC PCM5102')
    Lines.append('\ndtoverlay=hifiberry-dac\n')
    # enable software volumne control
    subprocess.run(['sudo cp sv_asound.conf /etc/asound.conf'], shell=True)
    
  elif dac.startswith('uda1334'):
    print('Generic DAC UDA1334')
    Lines.append('\ndtoverlay=hifiberry-dac\n')
    # enable software volumne control
    subprocess.run(['sudo cp sv_asound.conf /etc/asound.conf'], shell=True)
    
  elif dac.startswith('pcm5122'):
    print('DAC uses I2C & I2S PCM5122')
    Lines.append('\ndtoverlay=allo-boss-dac-pcm512x-audio\n')
    
  elif dac.startswith('wm8960'):
    print('DAC uses I2C & I2S WM8960; Waveshare Bd')
#    print('Run; sudo bash setupEV-Respeaker.sh')
#    subprocess.run(['sudo bash setupEV-Respeaker.sh'], shell=True)
    print('Run; sudo bash setupWaveshareWM8960.sh')
    subprocess.run(['sudo bash setupWaveshareWM8960.sh'], shell=True)
        
    
  elif dac.startswith('pcm5242'):
    print('DAC uses I2C & I2S PCM5242; IQAudio DAC+ Bd')
    # kill the HDMI audio to move PCM5242 to be card 0
    Lines.append('\ndtoverlay=iqaudio-dacplus\n')
  else:
    print('Unknown DAC, no DAC installed.')
  
except:
  print('You must specify a DAC to install, either;')
  print('PCM5102, UDA1334, PCM5122, PCM5242 or WM8960.')
  print('No DAC installed')

# add ADS1115 driver - with driver installed the I2C address 0x48 is grabbed by
# the driver. This means that the Adafruit python library cannot access the
# ADS1115 device at I2C address 0x48. If the driver is not installed then the
# Adafruit library works fine. I have been unable to find any info on how to use
# the device tree driver from a Python script. Nothing I found works.
# Lines.append('dtoverlay=ads1115\n')

#for l in Lines:
#  print(l)

# rename with .bak extention  
subprocess.run(['sudo cp ' + Filename + ' ' + Filename + '.bak'], shell=True)

# save changes
# write everything to a new file
with open(Filename, "w") as f:
  f.writelines(Lines)
#------------------------------------------------------------------------------


