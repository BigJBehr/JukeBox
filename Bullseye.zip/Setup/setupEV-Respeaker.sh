#!/bin/bash
echo "Installing git"
sudo apt-get install git -y
echo "Installing pip3"
sudo apt install python3-pip -y
sudo apt-get install libglib2.0-dev -y
#echo "Installing Events"
sudo apt-get install python3-dev -y
sudo apt-get install python3-evdev
echo "Installing Respeaker bd drivers"
git clone https://github.com/HinTak/seeed-voicecard
cd seeed-voicecard
sudo ./install.sh
echo "Rebooting"
sudo reboot now

