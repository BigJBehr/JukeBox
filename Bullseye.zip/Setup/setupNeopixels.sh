sudo pip3 install rpi-ws281x
#sudo pip3 install adafruit-circuitpython-pixel-framebuf
sudo pip3 install adafruit-circuitpython-neopixel


