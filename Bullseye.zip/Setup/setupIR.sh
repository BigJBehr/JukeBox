#! /bin/bash
sudo apt-get install ir-keytable -y
sudo cp *.toml /etc/rc_keymaps


