#! /bin/bash

cd work
sudo rm config.txt
sudo rm logind.conf
sudo rm rc.local
sudo rm rc_maps.cfg

sudo cp config.txt.bak config.txt
sudo cp logind.conf.bak logind.conf
sudo cp rc.local.bak rc.local
sudo cp rc_maps.cfg.bak rc_maps.cfg
cd ~

