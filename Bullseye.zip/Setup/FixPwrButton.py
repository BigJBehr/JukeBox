#! /bin/python3
# This script edits /etc/systemd/logind.conf to assign a different action to the
# Power_Key.
# You must run as sudo, type; 'sudo python3 FixPwrButton.py'

# 11-26-24

import subprocess
import sys

#Filename = "/home/bigj/work/config.txt"
Filename = "/etc/systemd/logind.conf"

Lines = []

#===== Main Program =====

# read file lines into a list then auto close
with open(Filename, "r") as f:
  Lines = f.readlines()

for i in range(0, len(Lines)):
  if Lines[i].startswith('#HandlePowerKey='):
    print('Power Button Fixed')
    Lines[i] = 'HandlePowerKey=suspend\n'
    break;

# write everything to a new file
with open(Filename, "w") as f:
  f.writelines(Lines)
  

