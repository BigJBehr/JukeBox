#! /bin/bash

pip3 install adafruit-circuitpython-rgb-display
sudo apt-get install fonts-dejavu -y 
sudo apt-get install python3-pil -y

