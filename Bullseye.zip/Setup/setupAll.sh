#! /bin/bash
START=$(date +'%s')

sudo apt-get update
sudo apt-get upgrade -y

sudo apt-get install python3-pip -y
sudo apt-get install libglib2.0-dev -y
sudo apt-get install python3-dev -y
sudo apt-get install python3-evdev
sudo apt-get install evtest -y
sudo apt-get install git -y
sudo apt-get install fonts-dejavu -y
sudo apt-get install python3-pil -y
sudo apt-get install build-essential
sudo apt-get install i2c-tools -y
sudo apt-get install python3-smbus -y

pip3 install sh
pip3 install pyudev
pip3 install pygame==2.6.1
pip3 install pygame --upgrade
pip3 install adafruit-circuitpython-rgb-display
pip3 install adafruit-circuitpython-neopixel
pip3 install rpi-ws281x
pip3 install adafruit_circuitpython-ads1x15

sudo mkdir /home/music
sudo mkdir /home/usb
sudo mkdir /home/nas

sudo cp *.automount /etc/systemd/system

# enable I2C and create I2c devices
sudo raspi-config nonint do_i2c 0

# disable power key to keep Pi from shutting down
sudo python3 FixPwrButton.py

# setup NAS drive to automount on boot
sudo python3 install-Nas.py

# install driver for DAC and make other changes
sudo python3 install-Dac.py

# install driver for IR Remote if needed
sudo python3 install-IR.py

END=$(date +'%s')
echo $END
echo $START
echo $((END - START))

echo "***** Rebooting *****"
sudo reboot now


