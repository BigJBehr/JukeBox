#!/bin/bash
echo "Installing pygame library ver 2.6.0"
python -m pip install pygame==2.6.0
#sudo apt-get install python3-pygame -y
echo "Installing I2C Support"
sudo apt-get install 12c-tools
sudo apt-get install python3-smbus
echo "Install Events"
sudo apt-get install python3-evdev

