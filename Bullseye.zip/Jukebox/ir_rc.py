#!/usr/bin/python3

# This class is for an IR remote control device that is derived from my
# remotControlDevice class. I am using this remote to control a music player.

# The advanatages of using an IR remote are simplicity and the receiver is always
# active. The disadvantages are; you must aim the remote at the the receiver,
# you will need an external IR receiver and it must be wired to the appropiate
# GPIO pin.

# There are currently two ways to do IR on Linux; LIRC and ir-keytable. Of the 
# two, ir-keytable is by far easier to setup than LIRC. If you want or need  to
# use multiple remotes then LIRC may be the way to go. This writeup is about
# using ir-keytable. If you want or need to use LIRC then I wish you luck in
# figuring out how to get it to work.

# ir-keytable is used for the IR interface. ir-keytable runs as a Linux service.
# It handles the receiving and decoding of the IR signals. The .toml file identifies
# the IR protocol used and provides a keycode-to-system-identifier lookup table.
# Received IR commands are passed as async events to running programs.

# When you enable IR capture in Linux (by adding 'dtoverlay=gpio-ir,gpio_pin=xx'
# to /boot/config.txt) an input device is created with the name 'gpio_ir_recv'.
# IR signals sent by the remote are captured and passed to ir-keytable which then
# decodes the IR signals and translates them into an event that holds information
# about the key that was pressed on the remote. The event is then available from
# the 'gpio_ir_recv' input device.

# The IR remote I am using is an MT4 Air Mouse BLE 5.2 Remote that is a combo
# IR and BLE remote. Other IR remotes can be used simply by making a .toml file
# for the target remote. The MT4 Air Mouse BLE 5.2 Remote is available from 
# Aliexpress for $3.24 + shipping. I chose this remote because it was inexpensive,
# has the bare minimum of buttons needed for an audio app and has BLE and
# learning IR. I am using the default IR codes, I did not teach it new IR codes.
# If this remote is paired with a Bluetooth host then it will stop transmitting
# IR codes otherwise it will send a BLE notifcation and an IR code when a key is
# pressed.

#===== Hardware =====
# RaspberryPi Zero 2 W or any Raspberry Pi
# Micro SD card with 64bit Bullseye, headless (no GUI)
# MT4 Air Mouse BLE 5.2 Remote (combo IR & BLE)
# A 3.3V IR receiver wired to a GPIO pin
# Appropiate 5V Power Supply

#===== Setup =====
# The following assumes you are starting with a freshly minted SD card. Bullseye
# was chosen over Bookworm due to the extra complexity of installing python
# libraries in Bookworm. KISS baby.

# At a minimum you will need all of the following files to be in you CWD. You
# can use something like WinSCP to copy the files to the Rpi;
# AirMouse.toml or the .toml file for your IR remote.
# remoteControlDevice.py
# ir-rc.py

# Several system files will need to be edited to allow ir-keytable to work. I
# use the nano editor.

# Enable IR signal capture
# type: sudo nano /boot/config.txt
# uncomment (remove leading '#'), gpio_pin is the gpio pin the IR detector is
# connected to. Any free gpio pin may be used. 
# Before: #dtoverlay=gpio-ir,gpio_pin=17
# After:  dtoverlay=gpio-ir,gpio_pin=17
# Save & exit. Press Ctrl-O, Enter, Ctrl-X.

# Install ir-keytable
# type: sudo apt-get install ir-keytable -y

# AirMouse.toml is the .toml file I developed for the AirMouse remote that I am
# using. It was created making a copy of an exiting .toml file and then editing
# it to match the Air Mouse remote. There are several online articles on how to
# install, configure and use ir-keytable with IR remotes.
# Use something like WinSCP to copy AirMouse.toml from your PC to the target RPi.

# Copy AirMouse.toml to /etc/rc_keymaps. Do ths after installing ir-ketable as
# the installation creates this directory and others and adds some .toml files
# tyoe sudo cp AirMouse.toml /etc/rc_keymaps/AirMouse.toml
# The above command assumes you have the .toml file in your CWD and the file name
# is 'AirMouse.toml'. 

# ir-keytable has several command line switches;
# -c -> clear out any old key tables (.toml files)
# -r -> show loaded key tables
# -t -> test key table, received IR is decoded and displayed as keycode & text name
# -w filename.toml -> load a key table
# -p -> sets the IR protocol; NEC, Sony, All for all protocols
# -s rcx -> sets the input device; rc0, rc1... for events.

# Test is usefull to determine what keycodes & protocol is used by your remote.
# This is helpful for creating a .toml file for your remote of choice.
# Use: ir-keytable -t -w All

# Sample .toml files can be found at; '/lib/udev/rc_keymaps'
# If one fits your remote then copy it to /etc/rc_keymaps
# If you want to use multiple IR remotes, you can have numerous .toml files in
# /etc/rc_keymaps. Each IR remote will be assigned an input device number; rcx
# according to position in the table. The top entry is rc0. Next is rc1,...etc. 
# Listen on each input device for IR events from the corresponding remote.

# To ensure that your IR remote is defined as rc0 then you need to edit;
# '/etc/rc_maps.cfg' and add your .toml file as the top entry.
# type: sudo nano /etc/rc_maps.cfg
# add: '*               *               AirMouse.toml' before the current top
# entry.
# Save & exit.

#===== Power Button =====
# The keycode sent by the power button on my remote is assigned to 'KEY_POWER'
# in the AirMouse.toml file. When the power button is pressed the system decodes
# 'KEY_POWER' as a command to shutdown the RPi system. If you do not want this
# behavior, you have two options. First, edit your .toml file and assign the
# keycode to a different 'KEY_xxx'. Or, edit /etc/systemd/logind.conf. Find the
# line; '#HandlePowerKey=poweroff'. Add a line after this one;
# 'HandlePowerKey=suspend'. Reboot, now the power button works like any other
# button.

#===== Run ir-keytable on Startup =====
# Edit /etc/rc.local
# Type: sudo nano /etc/rc.local
# Append to the end of the file, just above the line 'exit 0'
# Add: sudo ir-keytable -c -w /etc/rc_keymaps/Airmouse.toml

# This should be added before any commands to start something that uses the IR
# remote.

# Save & exit

# These are the event.codes I am using for the Air Mouse BLE 5.2 Remote keyboard.
# These are predefined in Linux events system. 
# Yours may be different.
# KEY-VOLUMEUP      - 115
# KEY_VOLUMEDOWN    - 114
# KEY_NEXT          - 407
# KEY_PLAYPAUSE     - 164
# KEY_PREVIOUS      - 412
# KEY_MUTE          - 113
# KEY_RIGHT         - 106
# KEY_LEFT          - 105
# KEY_UP            - 103
# KEY_DOWN          - 108
# KEY_OK            - 352
# KEY_BACK          - 158
# KEY_MENU          - 139
# KEY_POWER         - 116
# KEY_HOME          - 102
# Power button causes RPi to shutdown
# event.value has button state; 0 -> up, 1 -> down, 2 -> held


#===== Example of using ir-keytable with Python =====
from abc import ABC, abstractmethod

import time
import threading
import evdev

try:
  import queue as Queue
except ImportError:
  import Queue as Queue

from RemoteControlDev import RemoteControlDev

# class that encapsulates an IR remote using RemoteControlDev as the base class
class Rc_device(RemoteControlDev):
  def __init__(self, fn):
    RemoteControlDev.__init__(self)
    # fn is for compatibility, not used here
    # by using super() I can access the parents methods directly
#    super().__init__(self)
    
#------------------------------------------------------------------------------      

  # The code here is generic and should work with any IR remote. All you need is
  # to create or copy a .toml file tailored to your remote. 

  # this should be in it's own thread. received key events are pushed into a FIFO.
  # events are popped by the main thread and dispatched.

  # This is the thread that blocks until a command from the remote is received.
  # If this is a key event then push it into the fifo.
  def rcListener(self):
    # set the IR input device path
    # IR always has the same device name; 'gpio_ir_recv'
    if True == self.rcSetPath('gpio_ir_recv'):
      print('IR input device found')

      #prints out device info at start
      print(self.kybd)

# IR key events are translated by ir-keytable using you .toml file, so no need
# to translate here.
      while True:
        try:
          # evdev takes care of polling the controller in a loop
          # stalls here waiting for remote key events
          event = self.kybd.read_one()
          if (event):
            print("Received command: ", event.value)
            # the event is a key press event
            if event.type == evdev.ecodes.EV_KEY:  
  #            print(categorize(event))
              print('Code: ' + str(event.code))      # key code
              print('Value: ' + str(event.value))    # 0 -> down, 1 -> up, 2 -> held
              # push the key event into the fifo. this will block until room.
              self.fifo.put(event)

        except KeyboardInterrupt:
          # exit thread loop on ^C
          #raise SystemExit
          sys.exit()
          
      # end while
  #----------------------------------------------------------------------------    
#---- class end ---------------------------------------------------------------
 

 
