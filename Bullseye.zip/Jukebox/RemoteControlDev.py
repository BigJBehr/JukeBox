#!/usr/bin/python3

# This is the abstract class that all remote control devices are derived from.
from abc import ABC, abstractmethod

import threading
import time
import sys
import evdev

from evdev import *

try:
    import queue as Queue
except ImportError:
    import Queue as Queue

#------------------------------------------------------------------------------      

#==============================================================================
# Definition of the RemoteEvent structure used to pass an event to the main thread.
#==============================================================================
class RemoteEvent():
  def __init__(self, value, code):
    # we only ever send key events
    self.type  = evdev.ecodes.EV_KEY
    self.value = value
    self.code  = code
#----- End Class --------------------------------------------------------------
    
#==============================================================================
# class that encapsulates a remote control device
#==============================================================================
class RemoteControlDev:
  def __init__(self):
    self.fifo    = Queue.Queue(16)
    self.kybd    = None
    self.mouse   = None
    self.mac     = None
    self.battery = 0
    self.THandle = None
    
    # create thread for BLE remote listener
    print('Creating Listener thread\n')
    self.THandle = threading.Thread(target=self.rcListener, args=(), daemon=True)
    self.THandle.start();
#------------------------------------------------------------------------------      

  #============================================================================
  # Return true if the queue has a pending event.
  #============================================================================
  def rcHasEvent(self):
    return False == self.fifo.empty()
  #----------------------------------------------------------------------------      

  #============================================================================
  # Return the next event from the fifo. The event is removed from the fifo.    
  #============================================================================
  def rcGetEvent(self):
    return self.fifo.get()
  #----------------------------------------------------------------------------      

  #============================================================================
  # Return True if the thread is still running.
  #============================================================================
  def rcIsAlive(self):
    return self.THandle.is_alive()
  #----------------------------------------------------------------------------
        
  #============================================================================
  # Translate a keycode from the remote device into a system keycode and return
  # it. 
  #============================================================================
  def rcTranslate(self, kcode):
    return(kcode)
  #----------------------------------------------------------------------------      

  #============================================================================
  # Set the paths to the input devices for the remote. Remotes may have one or
  # two paths.
  # Return True is the keyboard path was set.
  #============================================================================
  def rcSetPath(self, kybdName, mouseName = None):
    # find the IR input device path
    devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
    for device in devices:
#      print(kybdName + ' ? ' + device.name)
      if (kybdName == device.name):
        print('Found Remote Keyboard: ' + device.name + ', ' + device.path)
        self.kybd = InputDevice(device.path)
        self.mac  = device.phys
      if None != mouseName and mouseName == device.name:
        print('Found Remote Mouse: ' + device.name + ', ' + device.path)
        self.mouse = InputDevice(device.path)
        self.mac   = device.phys
    # end for loop
    return(self.kybd != None)            
  
  #============================================================================
  # Remote listener thread. Allows remote interface to run independant of the
  # main thread. Sets up the link to the remote and listens for events.
  # Runs as a daemon thread (auto shutdown when program exits).
  #============================================================================
  @abstractmethod
  def rcListener(self):
    pass
    
