# Class for control of NeoPixel LEDs

#  7-23-24 - Added LED patterns as callable functions.
#  1-10-25 - Rewritten to use classes to add virtual LED strip segments.
#  1-11-25 - Four actions are working. Able to change action when song ends,
#            touch button pressed or up key pressed on remote.
#            Virtual LeD strips my all have the same action or different actions
#            for each strip. An action may use the whole strip.
#  1-16-25 - ADS1115 is funtioning properly. MSGEQ7 is not working.
#  1-17-25 - My MSGEQ7 board bad, works with good board.
#  1-30-25 - Conflict with Innomaker DAC Mini forces strobe to GPIO16.
#          - Added pause() to pause/unpause the LED action.

#===== To Do =====
# Add more music related actions.
# Add more non-music based actions.
# Intersperse music actions with non-music based actions.

import time
import board
import neopixel
import random
import threading
import RPi.GPIO as GPIO
import smbus
import busio
import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn

#try:
#    import queue as Queue
#except ImportError:
#    import Queue as Queue

ADC_PIN  = 4      # ADS1115 IRQ pin
RST_PIN  = 5      # MSGEQ7 Reset pin
STB_PIN  = 16     # MSGEQ7 Strobe pin

#bus = smbus.SMBus(1)
#time.sleep(1) #wait here to avoid 121 IO Error

class WS2812():
  def __init__(self, numpixels):
    self.adcbuffer = list()
    self.gain = 1
    self.THandle = None
    self.numpixels = numpixels
    self.ai = 1                 # action index -> chaser
    # default is auto_write enabled, this means we write the whole strip everytime
    # a pixel changes, very slow!. with auto-write disabled, the strip is written
    # to when .show() is invoked.
    self.pixels = neopixel.NeoPixel(board.D12, self.numpixels, auto_write=False)
    self.color = (0, 255, 0)
    self.acflag = False
    self.dirty  = False
    self.paused = False
            
    # create seven entries in the ADC buffer
    for i in range(0, 7):
      self.adcbuffer.append(0)

    # setup MSGEQ7 control pins as outputs
    GPIO.setmode(GPIO.BCM)      # use BCM pinout
    
    GPIO.setup(RST_PIN, GPIO.OUT)
    GPIO.output(RST_PIN, GPIO.LOW)  # hold reset low

    GPIO.setup(STB_PIN, GPIO.OUT)
    GPIO.output(STB_PIN, GPIO.HIGH) # set strobe high

    # create four virtual LED strips to represent the three LED pipes & top chamber.
    self.strips = list()

    # get the ADS1115 ready to read data from the MSGEQ7
    i2c = busio.I2C(board.SCL, board.SDA)
    # Create the ADS object and specify the gain
    self.ads = ADS.ADS1115(i2c)
    self.ads.gain = 1 
    # the MSGEQ7 is wired to channel 0 of the ADC
    self.chan = AnalogIn(self.ads, ADS.P0)

    # create thread for LED action engine
    print('Creating LED thread\n')
    self.THandle = threading.Thread(target=self.ledDispatcher, args=(), daemon=True)
    self.THandle.start();
  #----------------------------------------------------------------------------

  def reqActionChange(self):
    self.acflag = True
  #----------------------------------------------------------------------------

  def addStrip(self, strip):
    self.strips.append(strip)
  #----------------------------------------------------------------------------

  def pause(self, state):
    self.paused = state
  #----------------------------------------------------------------------------
  
  def nextAction(self):
    self.pixels.fill(BLACK)    # blank all LEDs
    
    self.ai += 1      # ai is the action index
    print('AI: ' + str(self.ai))

    if self.ai == 0:
      # setup for chaser
      print('Setup Chaser')
      for s in self.strips:
        s.setAction(s.actionChaser)
        s.action(True)
    elif self.ai == 1:
      # setup for full progressive
      print('Setup Full Progressive')
      for s in self.strips:
        s.setAction(s.actionFullProgressive)
        s.action(True)
    elif self.ai == 2:
      # setup for progressive
      print('Setup Progressive')
      for s in self.strips:
        s.setAction(s.actionProgressive)
        s.action(True)
    elif self.ai == 3:
      # setup for full chaser
      print('Setup Full Chaser')
      for s in self.strips:
        s.setAction(s.actionFullChaser)
        s.action(True)
    elif self.ai == 4:
      # setup for full random color
      print('Setup Full Random')
      for s in self.strips:
        s.setAction(s.actionFullRandom)
        s.action(True)
    elif self.ai == 5:
      # setup for full random color
      print('Setup Random')
      for s in self.strips:
        s.setAction(s.actionRandom)
        s.action(True)
    elif self.ai == 6:
      # setup for music drives brightness of strips
      # six bands are displayed on six half strips
      print('Setup musical fade')
      for s in self.strips:
        s.setAction(s.actionMusicFade)
        s.action(True)
        
# add full sparkle, audio bright, audio length, cylon eye, fades
    else:      
      # ai is out of bounds, default to chaser
      # setup for chaser
      print('Invalid AI: ' + str(self.ai))
      print('Setup Chaser..')
      self.ai = 0
      for s in self.strips:
        s.setAction(s.actionChaser)
        s.action(True)
  #----------------------------------------------------------------------------
  
  def cmd(self, index):
    self.fifo.put(index)
  #----------------------------------------------------------------------------

  def clear(self):
    print('LEDs Clear')
    self.pixels.fill((0, 0, 0))
    self.pixels.show()
  #----------------------------------------------------------------------------

  def setColor(self, color):
    self.color = color
  #----------------------------------------------------------------------------
        
  # Get the value of each of the seven frquency bands.
  # possible to use volume setting to adjust gain setting ?
  # this takes about 710us to read all seven values
  def getAdc(self):
    GPIO.setmode(GPIO.BCM)            # use BCM pinout
    GPIO.output(RST_PIN, GPIO.HIGH)   # reset MSGEQ7
    GPIO.output(STB_PIN, GPIO.HIGH)   # set strobe high
    time.sleep(0.000020)              # delay 20us
    GPIO.output(STB_PIN, GPIO.LOW)
    time.sleep(0.000055)              # delay 55us
    GPIO.output(STB_PIN, GPIO.HIGH)   # set strobe high
    GPIO.output(RST_PIN, GPIO.LOW)    # release reset
    time.sleep(0.000075)              # delay 75us
      
    # collect data
    for i in range(0, len(self.adcbuffer)):
      GPIO.output(STB_PIN, GPIO.LOW)
      time.sleep(0.000070)  # 70uS delay
      # read value from ADC
      # ADC reads as 16 bit signed value. there should be no negative values.
#      self.adcbuffer[i] = self.chan.value & 0x7FFF
      self.adcbuffer[i] = self.chan.value
      GPIO.output(STB_PIN, GPIO.HIGH)
#      print('Raw: ' + str(self.adcbuffer[i]))
      time.sleep(0.000010)  # 10uS delay
    # end for
  #------------------------------------------------------------------------------

  # Color Theater Chaser              
  def ops2(self):
    print('Ops2')
    for x in range(0, 20):  # sets how long to run for
      for y in range(0, 3):
        for z in range(0, self.numpixels, 3):
          # turn every third LED on
          if (y + z) < self.numpixels:
            self.pixels[y + z] = self.wheel((y + x) % 255)
        # end for

        self.pixels.show()
        time.sleep(.050)

        for z in range(0, self.numpixels, 3):
          # turn every third LED off
          if (y + z) < self.numpixels:
            self.pixels[y + z] = (0, 0, 0)
        # end for
      # end for
    # end for
    
  #----------------------------------------------------------------------------

  # Color Theater Chaser              
  def ops3(self):
    print('Ops3')
    for x in range(0, 256):
      for y in range(0, 3):
        for z in range(0, self.numpixels, 3):
          # turn every third LED on
          if (y + z) < self.numpixels:
            self.pixels[(y + z) % self.numpixels] = self.wheel((y + x) % 255)
          if (y + z + 1) < self.numpixels:
            self.pixels[(y + z + 1) % self.numpixels] = self.wheel((y + x + 64) % 255)
          if (y + z + 2) < self.numpixels:
            self.pixels[(y + z + 2) % self.numpixels] = self.wheel((y + x + 128) % 255)
        # end for
        
        time.sleep(.050)

#        for z in range(0, self.numpixels, 3):
          # turn every third LED off
#          self.pixels[y + z] = (0, 0, 0)
        # end for
      # end for
    # end for
    
  #----------------------------------------------------------------------------

  def wheel(self, wheelpos):
    wheelpos = 255 - wheelpos
    if wheelpos < 85:
      return (255 - wheelpos * 3, 0, wheelpos * 3)
    if wheelpos < 170:
      wheelpos -= 85;
      return (0, wheelpos * 3, 255 - wheelpos * 3)
    
    wheelpos -= 170
    return (wheelpos * 3, 255 - wheelpos * 3, 0);
  #----------------------------------------------------------------------------
                    
  def ledDispatcher(self):
    while True:
      if self.paused == False:
        if len(self.strips) > 0:
          for s in self.strips:
            s.doAction()
          
          if self.dirty == True:
            self.dirty = False
            self.pixels.show()
               
#        time.sleep(0.010)      # ten millisec delay
        
        if self.acflag == True:
          self.acflag = False
          self.nextAction()
#      else:

      time.sleep(0.010)      # ten millisec delay
    # end while
  #----------------------------------------------------------------------------
               
#----- end class --------------------------------------------------------------

GREEN  = (0, 255, 0)
RED    = (255, 0, 0)
YELLOW = (255, 255, 0)
BLUE   = (0, 0, 255)
CYAN   = (0, 255, 255)
PURPLE = (255, 0, 255)
WHITE  = (255, 255, 255)
ORANGE = (255, 37, 0)
VIOLET = (90, 0, 255)
LTGREEN = (90, 255, 0)
BLACK   = (0, 0, 0)

#GREEN =     0xFF000000
#RED =       0x00FF0000
#YELLOW =    (GREEN | RED)
#BLUE =      0x0000FF00
#CYAN =      (GREEN | BLUE)
#PURPLE =    (BLUE | RED)
#WHITE =     (BLUE | RED | GREEN)
#ORANGE =    0x25FF0000      # gamma corrected half green + full red
#VIOLET =    0x005AFF00      # gamma corrected ~3/4 red + full blue
#LTGREEN =   0xFF5A0000      # gamma corrected ~3/4 red + full green
#BLACK =     0x00000000

ColorTable = [GREEN, RED, YELLOW, BLUE, CYAN, PURPLE, WHITE, LTGREEN, ORANGE, VIOLET]
MAXCOLORS = len(ColorTable)

STRIP1FIRST = 0
STRIP2FIRST = 25
STRIP3FIRST = 48
STRIP4FIRST = 58



class LedStrip():
  def __init__(self, leds, first, len):
    self.leds = leds
    self.action = self.actionChaser
    self.first = first        # first pixel in virtual led strip
    self.last  = first + len  # last pixel + 1 
    self.delay = 5            # pixel change delay in 10mS increments, reload  
    self.ccreload = 500       # color change timer reload, 5sec
    self.pos = first          # current pixel position
    self.dir = 1              # default direction is forward
    self.extra = 0            # extra var
    self.r = 0                # color
    self.g = 0
    self.b = 0
    self.timer = 5            # delay timer
    self.cctimer = self.ccreload  # color change timer
  #----------------------------------------------------------------------------

  def setDelay(self, delay):
    self.delay = delay
  #----------------------------------------------------------------------------

  def setDirection(self, dir):
    self.dir = dir
  #----------------------------------------------------------------------------

  def setAction(self, action):
    self.action = action
  #----------------------------------------------------------------------------
  
  def setColor(self, r, g, b):
    self.r = r
    self.g = g
    self.b = b
  #----------------------------------------------------------------------------
    
  def setColorIndex(self, i):
    self.r = i
  #----------------------------------------------------------------------------

  def doAction(self):
    if self.action != None:
      self.action(False)   
  #----------------------------------------------------------------------------

  def clear(self):
    for i in range(self.first, self.last): 
      self.leds.pixels[i] = BLACK  
  #----------------------------------------------------------------------------
           
  def bumpColor(self): 
    # change color index, keep index in bounds
    self.r += 1
    if self.r >= MAXCOLORS:
      self.r = 0
  #----------------------------------------------------------------------------

  def actionFullProgressive(self, initialize):
    if initialize == True:
      print('initializing full progressive')
      # disable all strips except the first which uses all leds
      if self.first == STRIP1FIRST:
        self.delay = 5              # pixel change delay in 10mS increments
      else:      
        self.delay = 0              # disable strip
          
      self.cctimer = self.ccreload  # color change timer
      self.pos = 0                  # current pixel offset
      self.dir = 1                  # default direction is forward
      self.extra = 0                # extra var
      self.r = 0                    # color
      self.g = 0
      self.b = 0
      self.timer = self.delay
    else:
      # running full progressive
      if self.delay == 0:
        return
                
      self.timer -= 1
      if self.timer == 0:
        self.timer = self.delay

        self.leds.dirty = True
                         
        # set pixel to color
        self.leds.pixels[self.pos] = ColorTable[self.r]

        # next pixel
        self.pos += self.dir
  
        if self.pos >= self.leds.numpixels:
          self.pos = 0
          self.bumpColor()
          
        if self.pos < 0:
          self.pos = self.leds.numpixels - 1
          self.bumpColor()
  #----------------------------------------------------------------------------
  
  def actionProgressive(self, initialize):
    if initialize == True:
      print('initializing progressive')
      self.delay = 5                # pixel change delay in 10mS increments  
      self.cctimer = self.ccreload  # color change timer
      self.pos = self.first         # current pixel offset
      self.dir = 1                  # default direction is forward
      self.extra = 0                # extra var
      self.r = 0                    # color
      self.g = 0
      self.b = 0
      self.timer = self.delay
      
      # change direction and/or color and start time for each strip
      if self.first == STRIP2FIRST:
        self.dir = -1
        self.r   = 3
        self.timer = 2
      if self.first == STRIP3FIRST:
        self.r   = 6
        self.timer = 7
      if self.first == STRIP4FIRST:
        self.dir = -1
        self.r   = 9
        self.timer = 9
    else:
      # running progressive
      if self.delay == 0:
        return
        
      self.timer -= 1
      if self.timer == 0:
        self.timer = self.delay
         
        self.leds.dirty = True
        
        # set pixel to color
        self.leds.pixels[self.pos] = ColorTable[self.r]

        # next pixel
        self.pos += self.dir
  
        if self.pos >= self.last:
          self.pos = self.first
          self.bumpColor()
          
        if self.pos < self.first:
          self.pos = self.last - 1
          self.bumpColor()
  #----------------------------------------------------------------------------
  
  def actionChaser(self, initialize):
    if initialize == True:
      print('initializing chaser')
      self.delay = 10               # pixel change delay in 10mS increments  
      self.cctimer = self.ccreload  # color change timer
      self.pos = 0                  # current pixel offset
      self.dir = 1                  # default direction is forward
      self.extra = 0                # extra var
      self.r = 0                    # color
      self.g = 0
      self.b = 0
      self.timer = self.delay
      
      # change direction and/or color for each strip
      if self.first == STRIP2FIRST:
        self.dir = -1
        self.r   = 3
      if self.first == STRIP3FIRST:
        self.r   = 6
      if self.first == STRIP4FIRST:
        self.dir = -1
        self.r   = 9
    else:
      # running chaser
      if self.delay == 0:
        return
        
      if self.cctimer > 0:
        self.cctimer -= 1
      else:
        # color change timer done, reload
        self.cctimer = self.ccreload

        # change color, keep index in bounds
        self.bumpColor()

      self.timer -= 1
      if self.timer == 0:
        self.timer = self.delay
         
        self.leds.dirty = True

        # all leds in the strip are off
        self.clear()

        # set every third pixel to color
        if self.dir > 0:
          # forward
          for i in range(self.first + self.pos, self.last, 3):
            self.leds.pixels[i] = ColorTable[self.r]
        else:
          for i in range((self.last - 1) - self.pos, self.first, -3):
            self.leds.pixels[i] = ColorTable[self.r]

        self.pos += 1
        if self.pos >= 3:
          self.pos = 0
  #----------------------------------------------------------------------------
  
  # Each pixel gets a random color
  def actionRandom(self, initialize):
    if initialize == True:
      print('initializing random')
      self.delay = 5                # pixel change delay in 10mS increments
      self.cctimer = self.ccreload  # color change timer
      self.pos = self.first         # current pixel offset
      self.dir = 1                  # default direction is forward
      self.extra = 0                # extra var
      self.r = 0                    # color
      self.g = 0
      self.b = 0
      self.timer = self.delay

      # change direction and/or color for each strip
      if self.first == STRIP2FIRST:
        self.dir = -1
        self.r   = 3
      if self.first == STRIP3FIRST:
        self.r   = 6
      if self.first == STRIP4FIRST:
        self.dir = -1
        self.r   = 9
    else:
      # running random
      if self.delay == 0:
        return
                
      self.timer -= 1
      if self.timer == 0:
        self.timer = self.delay

        self.leds.dirty = True
                         
        # set each pixel in the virtual strip to a random color table entry
        for i in range(self.first, self.last - 1):
          # random color can be a random color index or random RGB
          self.leds.pixels[i] = ColorTable[random.randint(0, MAXCOLORS - 1)]
  #----------------------------------------------------------------------------
  
  def actionFullChaser(self, initialize):
    if initialize == True:
      print('initializing full chaser')
      if self.first == STRIP1FIRST:
        self.delay = 10             # pixel change delay in 10mS increments
      else:      
        self.delay = 0              # disable strip
          
      self.cctimer = self.ccreload  # color change timer
      self.pos = 0                  # current pixel offset
      self.dir = 1                  # default direction is forward
      self.extra = 0                # extra var
      self.r = 0                    # color
      self.g = 0
      self.b = 0
      self.timer = self.delay
      
      # change direction and/or color for each strip
      if self.first == STRIP2FIRST:
        self.dir = -1
        self.r   = 3
      if self.first == STRIP3FIRST:
        self.r   = 6
      if self.first == STRIP4FIRST:
        self.dir = -1
        self.r   = 9
    else:
      # running full chaser
      if self.delay == 0:
        return
        
      if self.cctimer > 0:
        self.cctimer -= 1
      else:
        # color change timer done, reload
        self.cctimer = self.ccreload

        # change color, keep index in bounds
        self.bumpColor()

      self.timer -= 1
      if self.timer == 0:
        self.timer = self.delay

        self.leds.dirty = True
        
         # all LEDs off, no write to strip
        self.leds.pixels.fill((0, 0, 0))

        # set every third pixel to color
        if self.dir > 0:
          # forward
          for i in range(self.pos, self.leds.numpixels, 3):
            self.leds.pixels[i] = ColorTable[self.r]
        else:
          for i in range((self.leds.numpixels - 1) - self.pos, 0, -3):
            self.leds.pixels[i] = ColorTable[self.r]

        self.pos += 1
        if self.pos >= 3:
          self.pos = 0
  #----------------------------------------------------------------------------
  # Each pixel gets a random color
  def actionFullRandom(self, initialize):
    if initialize == True:
      print('initializing full random')
      # disable all strips except the first which uses all leds
      if self.first == STRIP1FIRST:
        self.delay = 5              # pixel change delay in 10mS increments
      else:      
        self.delay = 0              # disable strip
          
      self.cctimer = self.ccreload  # color change timer
      self.pos = 0                  # current pixel offset
      self.dir = 1                  # default direction is forward
      self.extra = 0                # extra var
      self.r = 0                    # color
      self.g = 0
      self.b = 0
      self.timer = self.delay
    else:
      # running full random
      if self.delay == 0:
        return
                
      self.timer -= 1
      if self.timer == 0:
        self.timer = self.delay

        self.leds.dirty = True
                         
        # set each pixel to a random color table entry
        for i in range(0, self.leds.numpixels):
          # random color can be a random color index or random RGB
          self.leds.pixels[i] = ColorTable[random.randint(0, MAXCOLORS - 1)]
  #----------------------------------------------------------------------------
  
  def actionMusicFade(self, initialize):
    if initialize == True:
      print('initializing musical fade')
      self.delay = 1                # pixel change delay in 10mS increments  
      self.cctimer = self.ccreload  # color change timer
      self.pos = self.first         # current pixel offset
      self.dir = 1                  # default direction is forward
      self.extra = 0                # extra var
      self.r = 0                    # MSGEQ7 audio channels to use
      self.g = 6
      self.b = 0
      self.timer = self.delay
      
      # change color for each half strip. only the first virtual strip is used.
      if self.first == STRIP2FIRST:
        self.r = 1
        self.g = 5
        self.delay = 0
      if self.first == STRIP3FIRST:
        self.r = 2
        self.g = 4
        self.delay = 0
      if self.first == STRIP4FIRST:
        self.r = 3
        self.g = 4
        self.b = 5
        self.delay = 0
    else:
      # running musical fade
      # data from the MSGEQ7 is collected using the ADS1115 ADC. the data is the
      # amplitude of the band. each band is assigned one half of an LED strip. 
      # the three center bands are assigned to the three colors of the top chamber
      # LEDs. the result is hue changes with the music. 
      if self.delay == 0:
        return
        
      self.timer -= 1
      if self.timer == 0:
        self.timer = self.delay

        # read MSGEQ7 data into the buffer         
        self.leds.getAdc()

#        for i in range(0, len(self.leds.adcbuffer)):
#          print('Raw2: ' + hex(self.leds.adcbuffer[i]))
#        print('=====')
                       
        self.leds.dirty = True
        
        # 0 red
        for i in range(0, 12):
          self.leds.pixels[i] = (self.leds.adcbuffer[0] >> 7, 0, 0)
        
        #6 purple
        for i in range(13, 25):
          self.leds.pixels[i] = (self.leds.adcbuffer[6] >> 7, 0, self.leds.adcbuffer[6] >> 7)
        
        # 1 blue
        for i in range(25, 36):
          self.leds.pixels[i] = (0, 0, self.leds.adcbuffer[1] >> 7)
        
        # 5 yellow
        for i in range(37, 48):
          self.leds.pixels[i] = (self.leds.adcbuffer[5] >> 7, self.leds.adcbuffer[5] >> 7, 0)
        
        #2 green
        for i in range(53, 58):
          self.leds.pixels[i] = (0, self.leds.adcbuffer[2] >> 7, 0)
        
        # 4 cyan
        for i in range(48, 53):
          self.leds.pixels[i] = (0, self.leds.adcbuffer[4] >> 7, self.leds.adcbuffer[4] >> 7)
        
        # 2, 3, 4 mix
        for i in range(58, 71):
          self.leds.pixels[i] = (self.leds.adcbuffer[2] >> 7, self.leds.adcbuffer[3] >> 7, self.leds.adcbuffer[4] >> 7)  
  #----------------------------------------------------------------------------
  #----------------------------------------------------------------------------
  #----------------------------------------------------------------------------
#----- end class --------------------------------------------------------------

