#! /bin/python3
# Shebang for Bullseye

# This script is for a Music Player running on an RPiZ2W with a Seeed 2 mic voice
# card (Keye Respeaker bd). The player accesses a NAS drive to get songs to play.
# A display shows artist, album & song currently playing. The Respeaker bd also
# allows for voice control and has three APA102 addressable LEDs and a pushbutton
# switch. This was developed for 64bit Bullseye Lite & Python3.

# I would like to state for the record that I am a retired Embedded Systems
# Engineer with limited experiance using the RPi, Linux and Python. I spent a
# lot of time searching the Internet for examples and how to(s) inorder to find
# the ones that actully work on Bullseye. There are a lot of how to(s) that are
# no longer valid or work with a previous OS. 
# The bulk of the Python code should work with alternative audio DAC boards. If 
# you use a different display then you will need to figure out how to use the
# display with Python. I am not a fan of Python as it combines the worst of the
# Basic and Fortran languages. However, it is the 'lingua franca' of the RPi.
# My choice would have been Java, C or C++.
# Please do not ask me to make modifications to use different hardware than
# what is specified. Think of it as a learning experiance.

# To use the APA102 LEDs on the respeaker bd, the file apa102.py must be in the
# same directory as this python3 script or the methods are cut & pasted into the
# main Python script.

# The Raspberry Pi Bullseye OS has built-in support for IR and the RPiZ2W has
# Blutooth built-in. The Respeaker board supports voice commands similar to
# Amazon Alexa or Google Home. To use IR you must add an external IR receiver.

# Remote control is achieved by using either ir_rc.py for IR or bt_rc.py for
# Bluetooth remotes. You can use either a Bluetooth Classic or a BLE remote, as
# long as you pair it with your RPi. You must provide a remote-keys-to-event-keycodes
# file. For an IR remote, this would be a .toml file. For Bluetooth remotes you
# need a json formatted text file. Examples are provided. It is very easy to
# find the keycodes sent by your remote and edit one of the files to match your
# remote. See the bt_rc.py module for how to pair a remote and how to find your
# keycodes.

# The Air Mouse BLE 5.2 Remote was chosen because it uses BLE and the buttons
# are labeled as a simple audio device remote. Also it was inexpensive. IR
# transmission is blocked when the remote is paired. Works very well as an IR
# or a BLE remote. 

# To test for nearby BLE devices and reveal their MAC addresses, type;
# type; sudo bluetoothctl
# type; scan on
# Type; 'quit'  to exit
# You may have to press a button on the remote to 'wake' it up.

#===== Hardware =====
# Raspberry Pi Zero 2 W
# SD Card with 64bit Bullseye Lite OS
# Repeaker hat or Inno Maker Dac Mini or PCM5102 or UDA1334 or PCM5122 or PCM5242
# ILI9143 320x240 TFT LCD display
# MT4 BLE 5.2 Air Mouse Remote. Available from Aliexpress for $2.83 + shipping.
# Or BPR1S Remote Control. Available from Aliexpress for $3.77 + shipping.
# Or IR remote.
# SK6812 and WS2812B LED strip, 71 LEDs total.

# It is expected that you have some knowlege of basic Linux cmds, the nano
# editor, Putty (SSH), WinSCP and the RPi. A headless OS is used so everthing is
# done on the command line using SSH or direct connection of a monitor & keyboard.
# A mouse is not required.

# You can get the IP address of your RPi by typing; ifconfig

# My standard practice is to use the MAC address of the RPi to setup a fixed IP
# address from my router. How you do this varies from router to router, so you
# are on your own. I label each RPi with it's IP address, so I always know which
# board I am using.

# On my NAS the music is organized by Artist/Album/Songs. If you do not follow
# this arrangement then you may need to modify how the lists are created and how
# data is displayed on the display.

# The Respeaker board has three addressable APA102 (Dotstar) LEDs wired to SPI
# mosi and sclk without any chip select (CS/CE). Therefore adding another SPI
# device will mess with the LEDs. Might be possible to use a secondary SPI or
# an alternate sclk on a different GPIO pin ??

#=====System Setup =====
# There are several packages and Python3 libraries to load. This is a long process
# that can take longer on slower RPi boards or slow SD cards. Take your time to
# do it right. RPiZ2W is roughly same performance as an RPi3B. Comment lines start
# with '# X' where 'X' is a capital letter. Do not use cheap SD cards with your
# RPi. Spend the extra few dollars to get a good, fast name brand SD card. The
# performance difference between a cheap SD card from China and a Patriat or
# SanDisk SD card is a real eye opener. 

# I have provided several setupXXX.sh bash scripts to make setup easier and less
# error prone. The XXX part of the name identifies what gets installed. The step-by-step
# setup is provided in this script. The choice is yours. You can run one of the
# bash scripts by typing; sudo bash setupXXX.sh

# This has been reduced to one bash script, setupAll.sh and four python scripts.
# The bash script installs all the required python libraries. The python scripts
# are used to edit system files to; setup the NAS drive to automount on startup,
# enable I2C, I2S and SPI interfaces, install the driver for your DAC and more.

# If you create your own bash scripts you should be aware that the bash shell
# included with Bullseye is very picky about end-of-line characters. It will
# reject any command that does not end with only a linefeed ('\n', Linux standard).
# Make sure you use an editor that follows the Linux standard. I use nano, but
# other Linux based editors should work. Be cautious of Windows based text editors
# as they typically use the DOS standard of carriage return & linefeed ('\r\n'). 

# At the time of writing this I am having issues with Bookworm and RPi5B.
# Bookworm appears to have issues with pygame ver 2.6.0. The previous version of
# pygame did not exhibit this issue when run on Bookworm.

# The design of the RPi5B moved the GPIO pin control to the new south bridge chip.
# The result is that the python libraries that allow control of the GPIO no longer
# work. A replacement library is available, however, the API is incompatible with
# the current python libraries. All the libraries that depend on the GPIO library
# are no longer working. This is just about everything that this project uses;
# no SPI display, no I2S for audio, no I2C, etc. 

# If you would rather do everything manually;

# Make OS changes to add drivers and settings for added hardware.
# First update/upgrade everything & reboot
# type; sudo apt-get update
# type; sudo apt-get upgrade -y
# type; sudo reboot now

# Install git
# type; sudo apt-get install git -y

# Install pip3. Needed for adding Python3 librarys
# type; sudo apt install python3-pip -y

#----- Setup for Bluetooth Remotes -----
# How to setup for Bluetooth is in the bt_rc.py file.

#----- Install Respeaker board drivers -----
# Use git to download drivers for the Respeaker board
# type; git clone https://github.com/HinTak/seeed-voicecard

# type; cd seeed-voicecard
# This step takes a long time complete
# type; sudo ./install.sh
# type; sudo reboot now

# Check driver installation
# type; aplay -l
# The seeed-2mic-voicecard should be listed. If not you used the wrong driver
# pack for the OS you are using.

# Test Recording
# type; arecord -D "plughw:1,0" -f S16-LE -r 16000 -d 5 -t wav test.wav
# Speak into the mic, collects sound for five seconds

# Test Playback
# type; aplay -D "plughw:1,0" test.wav

# Install Respeaker board demo programs
# type; git clone https://github.com/respeaker/mic_hat.git
# type; cd mic_hat
# type; sudo apt-get install portaudio19-dev libatlas-base-dev -y
# type; pip3 install -r requirements.txt

# Run the demos to test the LEDs & button
# From the mic_hat directory...
# type; cd interfaces
# type; python3 pixels.py
# Type; 'Ctrl C' to exit pixels.py
# The LEDs on the Respeaker board should cycle through some color patterns

# Test the pushbutton switch on the Respeaker board
# type; python3 button.py
# The state of the pushbutton is shown
# Type; 'Ctrl C' to exit button.py
# Get back to home directory
# type; cd ~

# The three Dotstar LEDs on the Respeaker board use the SPI port without a CS line.
# This means that if you use a TFT display that uses SPI it will intefere with
# the operation of the LEDs. The LEDs may do strage things while talking to the
# LCD display.
# If you want to use the three LEDs an the Respeaker board then 
# copy mic_hat/interfaces.apa102.py to your working directory.

#----- WS2812B Driver Installation -----
# type; sudo pip3 install rpi_ws281x
# type; sudo pip3 install adafruit-circuitpython-neopixel

#----- UDA1334 Alternative Audio DAC -----
# The UDA1334 board is a good alternative to the Respeaker board. The UDA1334 is
# just an audio DAC. It does not have microphones, a pushbutton nor Dotstar LEDs.
# To install the drivers and configure the system for the UDA1334, type the
# following
# type; curl -sS https://raw.githubusercontent.com/adafruit/Raspberry-Pi-Installer-Scripts/master/i2samp.sh | bash

# After rebooting, log back in and re-run the script again...It will ask you if you want to test the speaker. 
# Say yes and listen for audio to come out of your speakers...

#----- Generic I2S DACs (PCM5102A, UDA1334) -----
# These DACs only require an I2S connection. These DACs typically do not have 
# hardware volume control. To use softvol for volume control, copy sv_asound.conf
# to /etc/ and rename it to asound.conf.
# type; sudo mv -f sv_asound.conf /etc/asound.conf

# Edit /boot/config.txt
# Add to end of file; dtoverlay=hifiberry-dac
# Comment out the following;
# dtparam=audio=on
# camera_auto_detect=1
# display_auto_detect=1
# As long as you are there, uncomment; 
#dtparam=i2c_arm=on
#dtparam=i2s=on
#dtparam=spi=on

#----- Inno-Mker DAC Mini with PCM5122 DAC -----
# Edit /boot/config.txt
# Add to end of file; dtoverlay=allo-boss-dac-pcm512x-audio
# Alterative driver is; dtoverlay=hifiberry-dac-plus
# Comment out the following;
# dtparam=audio=on
# camera_auto_detect=1
# display_auto_detect=1
# As long as you are there, uncomment; 
#dtparam=i2c_arm=on
#dtparam=i2s=on
#dtparam=spi=on

# If using IR, uncomment the following; dtoverlay=gpio-ir,gpio_pin=xx
# Change 'xx' to the GPIO pin you connected the IR receiver to.
# Inno-Maker DAC Mini uses GPIO26 for IR capture.
#
#----- Test for aslamixer installed-----
# alsamixer should be installed by default. If not do the following
# type; sudo reboot now
# type; alsamixer
# press F6 on your keyboard, a dropdown list of available sound devices will appear
# Use down arrow key to select the 'seeed-2mic-voicecard' then press Enter. Press
# the Esc key to exit

#----- Install pygame library -----
# Install pygame library
# Pygame is used to play MP3 files
# type; sudo apt-get install python3-pygame -y

#---- Create a directory to mount the network share in /home/pi/music -----
# This program accesses a MP3 files on a NAS server.
# Where to mount the NAS share. Make sure that you are in your 'home' directory
# type; cd ~
# If you change the name of the 'music' directory then you will need to adjust
# the Python code to use the new directory.
# type; sudo mkdir music

# Skip these steps if music is stored on your SD card, USB drive or other local
# storage

#----- If using NAS drive to store your music -----
# Latest version of this script has a remount() function to mount the NAS share
# if it is not mounted. Therefor modifing /etc/fstab is not required, but does
# not hurt.

# Alterative would be to try to use systemd to automount the NAS share.

# Edit /etc/fstab to mount NAS drive on RPi
# type; sudo nano /etc/fstab
# Add the following line to bottom of /etc/fstab
# Change the IP address and music share path to match your network setup.
# type; //192.168.0.21/ix2-dl/Music/Player/ /home/nas cifs guest,_netdev 0 0
# login as guest does not require a password, has read only privledges.
# For the Synology NAS use;
# //192.168.0.23/Shared/Player/ /home/nas cifs username=guest,password=,_netdev 0 0
# Reboot
# type; sudo reboot now

# To test for successful mount, you should see a listing of all your music files
# type; ls /home/nas -l

#-----

# Optional to play MP3 files stored on the boot SD card, use WinSCP or similar
# to copy your music to the SD card music directory Just make sure to have an SD
# card that has the capacity to hold your music files. High speed SD cards are
# preferred (Brand matters, I use Patriot SD cards). Cheap SD cards are usually
# much slower, resulting in longer boot and installation times.

#----- If using the 2004LCD display -----
# type; sudo apt-get install 12c-tools -y
# type; sudo apt-get install python3-smbus -y

# Use i2cdetect to get the display's I2C address.
# type; sudo i2cdetect -a 1

#----- If using an ILI9341 TFT display -----
# type; sudo pip3 install adafruit-circuitpython-rgb-display
# type; sudo apt-get install fonts-dejavu
# type; sudo apt-get install python3-pil

#----- Events For Button Detection -----
# Install dev & test tools 
# type; sudo apt-get install python3-evdev
# type; sudo apt-get install evtest

#----- To run on boot up, do this after verifying that everything works. -----
# Add the cmd to rc.local
# type; sudo nano /etc/rc.local
# Add; 'sudo python3 /home/username/JukeBox.py &' to the line just before 'exit 0'
# Should look like this;
# sudo python3 /home/username/JukeBox.py &
# exit 0
# Save & exit.
# To stop auto run; edit rc.local and place an '#' as first character of the cmd
# to run JukeBox.py 

#----- Fixes for RPiZ2W WiFi dropouts -----
# The dropouts were being caused by a defective NAS device.
# Turn off power management
# type; sudo iwconfig wlan0 power off
# Raise CPU voltage
# type; sudo nano /boot/config.txt
# add; power off

#----- Enable systemd automount for the NAS share -----
# Change entry in /etc/fstab to add automount parameters.
# type: sudo nano /etc/fstab
# After '_netdev' and before ' 0 0' insert the following;
# 'x-systemd.automount,x-systemd.idle-timeout=60s'
# Save & exit

# There should be an .automount file in your home folder. This needs to be copied
# or moved to /etc/systemd/system/.
# type: sudo cp home-username-music.automount /etc/systemd/system/

# type: systemctl status home-username-music

# Pyudev is used to get udev notifcations for USB devices being plugged and unplugged.
# With udev notifications a USB memory stick can be detected and auto mounted.
# type: pip3 install pyudev

# This is how the 40 pin GPIO header of the RPi is allocated to handle the SPI
# interface to the TFT display, the I2S allocation to the DAC, the interface to
# the Pico for LED control and/or the allocation to control the LEDs directly
# (no Pico) and control the ADS1115 & MSGEQ7.
#----- GPIO Allocation ----
# GPIO2  - SDA,  I2C data
# GPIO3  - SCL,  I2C clk
# GPIO4  - IRQ,  ADC1115
# GPIO5  - OUT,  MSGEQ7 Reset/Pico Enable LEDs signal
# GPIO6  - OUT,  Mute input (Innomaker DAC- mini) 
# GPIO7  - CS1,  Display CS
# GPIO8  - CS0,  Touch CS
# GPIO9  - MISO, Touch MISO
# GPIO10 - MOSI, Display & Touch MOSI
# GPIO11 - SCLK, Display & Touch SCLK
# GPIO12 - OUT,  WS2812B LED out  
# GPIO13 - BKL,  Display Backlight
# GPIO14 - TX,   UART
# GPIO15 - RX,   UART
# GPIO16 - OUT,  MSGEQ7 Strobe/Pico Next signal
# GPIO17 - BTN,  DAC Bd push button input (Respeaker & Waveshare WM8960)
# GPIO18 - BCLK, I2S BCLK
# GPIO19 - LCK,  I2S LCK
# GPIO20 - IRQ,  Touch IRQ in
# GPIO20 - DIN,  I2S data in (respeaker & IQAudio Pi Dac Pro)
# GPIO21 - DOUT, I2S data out
# GPIO22 - DC,   Display DC
# GPIO23 - RST,  Display Reset
# GPIO24 - TBTN, Touch button in 
# GPIO25 - 
# GPIO26 - IR Receiver (Innomaker DAC-mini, PiFi DAC+)
# GPIO27 - Mute output (IQAudio Pi Dac Pro)


#----- Development Log -----
# 3-6-19  - it works !!!

# 3-16-24 - Modified to run on RPiZ2W with Respeaker Bd.
#           Seems to select correct output now
#           No volume unless I manually set it with alsamixer

# 3-19-24 - Modified to make a list of Artists then select one at random,
#         - make a list of albums by the artist, walk the list of albums,
#         - for each album make a list of songs, play each song then next
#         - album. After last album, remove Artist from list.
#         - appears to be working !!!!

# 3-22-24 - Added code to setup mixer volume on program start, works.
#         - Added IR receiver as daemon thread. Thread is running.
#         - IR capture events are happening
#         - Added button initialization code.

# 3-23-24 - Changed to use gpiozero for button press detection, works.
#         - Started cleanup of installation notes

# 3-25-24 - Continued cleanup of code & installation notes

# 4-9-24  - Merged with BLE remote code. BLE remote can; raise/lower volume,
#         - pause/unpause, need mute/unmute
#         - if remote not found it will hang the thread on timeout

# 4-11-24 - Switched to 20x4 LCD display.
#         - Volume & Pause are working.

# 4-12-24 - Fixed LCD  to center short lines and limit lines to 20 chars

# 4-13-24 - Improved BLE loop, allows for loss & recovery of remote.

# 4-14-24 - LCD is not thread safe. Causes lockups when updating ble info.
#           BLE still has issues with drop out & recovery. was missing outer while
#           Need to be able to save/restore volume settings ?
#           Changed default volume level to 50%

# 4-16-24 - LcdRow class is working. row scrolling works !!! 
# 4-17-24 - 4th Row has 'Paused' message
# 4-18-24 - 4th Row has 'Paused' message or Battery %.
#         - Added thread lock to LcdRow class
#         - Periodically read battery percentage & display in 4th row 
# 4-19-24 - Modified to continue scrolling for 5 steps after the end of the string
# 4-22-24 - Fixed Power button

# 4-24-24 - Writing to the LCD while the backlight is turned off turns the
#           backlight back on. This manifests when a row is scrolling and the
#           power is turned off.

# 4-27-24 - Rewrote the Bluetooth remote code to be a 'plugin' module. Just
#           uncomment the driver for the type of remote you are using and comment
#           out the ones you are not using.
#           Commands from the remote are processed on the main thread.
#           The 20x4 LCD is now also a 'plugin' module.
#           Button events toggle a flag in the main thread.

# 4-29-24 - Threw an unhandled exception when it could not load a music file.
#           Wrapped the try block in a while loop to force retries.
  
# Script works well during the day. When left paused overnight the script dies.
# I can SSH into the system and isssue a reboot. 
# 4-29-24 - Main thread died due to unable to load song file exception.

# Add code to reboot if the NAS mount fails ?

# 6-2-24  - Add code to periodically ping router when paused (try to keep wifi
#           alive). This seems to work, WiFi does not drop out overnight.

# 6-5-24  - LCD failed overnight. Looks like thread died ???

# 6-18-24 - Added exception handling to pinger, extended time between pings.

# 6-23-24 - Disabled LCD, seems to be major source of overnight death.
# 6-24-24 - Disabled pinger, does not do the job.
#           After some time, the server no longer responds to ping request.

# 6-25-24 - WiFi dropped out overnite while paused. Hung the JukeBox process.
#           Adding code to turn off auto wifi power off when script starts.
#           Changed to IR on GPIO12 foe remote control.

# 6-26-24 - Added code to detect when the NAS share is not mounted and mount it. 
#         - Did not see any Wifi dropouts overnight.

# 6-27-24 - Removed all traces of pinger RIP.
#         - No WiFi dropouts overnight. However, server had a hiccup and was
#         - offline this morning. PC reboot fixed server & music started playing.
#         - Re-enabled LCD.

# 6-28-24 - Fixed issue with song name less than three bytes long.
#         - Added remount() prior to making song or album lists.

# 6-29-24 - Rewrote remote control to handle Bluetooth & IR devices the same.
#         - Major re-write for BLE, minor for Classic & IR. 

# 7-01-24 - Changed to use systemd automount feature. This will auto mount the
#         - NAS share on any access and auto unmount the NAS share after an idle
#         - timeout defined in: '/etc/systemd/system/home-bigj-music.automount'.
#         - Removed remount(), not needed with automount enabled.

# 7-4-24  - New remote control classes are working for IR & BLE remotes.

# 7-5-24  - Changed what is printed when no function is assigned to a keycode.

# 7-7-24  - Changed to using an ILI9341 TFT (320x240) display in landscape mode.

# 7-9-24  - Basic 320x240 TFT works. Time to snaz it up a bit.
#         - Does not start to play next song unless a button on the remote is
#         - pressed.

# 7-13-24 - 320x240 TFT LCD works fine, although very slow.
#         - Switched to IR. Switched to PCM5122 DAC. 
#         - Switched to automounting the Synology NAS. This is a test to see if
#         - wakeup issue is endemic to all servers or limited to the Lenovo NAS. 

# 7-14-23 - Attempting to speed up the TFT display. Worked.
#         - Changed checkNas(), added counter & keyboard interrupt.
#         - Changed powerKey() to turn on/off the display's backlight
#         - Not connecting to NAS on startup, so script fails. Adding retries
#         - and a delay.

# 7-15-24 - Switched to IR remote.

#  7-16-24 - Switched to Bluetooth remote. Changed to ST7789 240x280 IPS display.
#          - Fixed bug in getSongs(), would not accept file extensions that were
#          - in uppercase.

#  7-20-24 - Changed to ILI9341 LCD Display & Bluetooth remote

#  7-22-24 - Added WS2812B LED driver. Attached 24 LED ring.

#  7-23-24 - Colored lights ! Add new LED patterns accessable by remote.

#   8-9-24 - Modified to read configuration from file.

#  8-10-24 - Fresh install. Ported JukeBox_tft with NeoPixels to here. Extended
#          - LED string to 58 LEDs. High density LED count will be 157.

#  8-11-24 - Add thread to run ADC, collecting data from MSGEQ7.

# 10-8-24  - Rewrote MSGEQ7 driver. seem to be collecting good data now.

# 10-19-24 - RPiZ2W is not doing a good job driving LEDs. The LED drive writes
#            the whole strip every time an LED is changed. This results in
#            noticeable delays during updates. Collecting from MSGEQ7 is also
#            slow.
#            Arduino Nano works great to drive the LEDs & work the MSGEQ7. No
#            need for RPi Pico, although could be used in place of arduino.
#            RPi Pico ~ $5.00. Arduino Nano ~ $2.50, Arduino mini ~ $1.00. 

# 10-23-24 - Removed LED control & ADC. Now done by RPi Pico. Add touch for the
#            TFT LCD.

# 10-24-24 - Added seed value to random number generator.

# 11-17-24 - Added GPIO25 as End-of-song pulse to change LED action.
#            Added GPIO12 as LED disable. 0-> LEDS run, 1-> LEDs are dark.

# 11-21-24 - GPIO to pico not working.
#            Setup remote keys to toggle GPIO pins.
# 11-25-24 - Fixed GPIO issue, all works. Remote can change GPIO pins.

# 12-2-24  - Changed LED disable to disable when low.
#            Added function to disable LEDs on program exit.
#            Added skip & rewind functions.

# 12-18-24 - Started to add ability to use USB device as music source.
#            Added handler for USB add/remove events.
#            Able to detect USB and auto mount it. Also can detect USB removal.

# 12-19-24 - Attempting to mount any USB devices on program startup. Working.
#          - USB device takes precedence over NAS device for music.

# 12-21-24 - USB added event is switching to USB drive.
#          - USB removal event is switching to NAS.
#          - Startup with USB inserted uses USB.

# 12-23-24 - Added music source (NAS/USB) to bottom row of the TFT.

# System keeps advancing the USB drve letter on each insertion of the same drive.
# sda1 -> sdb1 -> sdc1...

# 12-24-24 - Added umount when USB removed, failed.
#            Validated that system runs on RPiZW.

# 12-25-24 - Added Pg.mixer.music.unload whenever a MusicPath change occures.
#            Updated pygame to 2.6.0. Fixed umount issue.
# Problem was caused by not unloading the music player's file from the USB source
# and not being able to un-mount USB drive due to it being 'busy'. Solved by
# manually upgrading pygame to ver 2.0 or greater.
# type; python -m pip install pygame==2.6.0
# As of the writing of this, 2.6.0 is the latest release of pygame.

# 1-1-25   - Corrected pinout table.
#          - Change over to pygame 2.6.0 broke the play loop, get_busy() will now
#          - return false when paused. Correct play loop to stay paused when paused.

# 1-2-25   - Changed to drive LEDs directly. Also added support for ADS1115 & MSGEQ7.

# 1-9-25   - LEDs are working, does not seem to affect audio playback.
#            Top touch switch is working. Respeaker button is ready to use, ADS1115
#            Irq detection is ready, MSGEQ7 control pins are ready.
#            LEDs need a lot of work !!!

# 1-12-25  - added code to collect data from the MSGEQ7 using the ADS1115 adc.
 
# for some unknown reason, the audio device name is not matching. This is causing
# a long delay before moving on with the correct audio device.
# something to do with pygame 2.6.0 ?

# 1-13-25  - Uncommenting 'dtparam=i2c_arm=on' does not create the i2c-01 device.
#          - Running raspi-config does.

# 1-27-25  - Ported to 172. Converted to Pico based LEDs
# 1-29-25  - Finished port. All working now.
#          - Added code to force garbage collection when 'powered off'.
#          - Conflict with GPIO6 & Innomake Dac mini forced pin change for Pico
#          - next action signal to GPIO16.

#  1-30-25 - Changed to get Pico/no Pico from config file. PicoFlag controls
#          - how GPIO5 & GPIO16 operate (control of the Pico or control of the
#          - MSGEQ7)
#          - Works with No Pico (RPiZ2W-171). Yet to test with Pico.
#  1-31-25 - Works with Pico (RPiZ2W-172).
#          - Touch sw moved to RPi GPIO24, no more Touch sw on Pico.

#  2-1-25  - Added code to show CPU internal temperature.
#  3-18-25 - Moved CPU temperature line up to clear "Paused" message erasure.

#  4-8-25  - Moved CPU temperature up to not overlap source.
#          - Modified to move an artist to the end of the list after playing all
#          - albums by the artist. The number of artists is decremented. This was
#          - done to prevent ransom choice from selecting an artist that has
#          - already been played. When list is empty then set number of artists
#          - back to list length.
#          - Modified to use touch button to 'wake up' a powered down unit.
   
#----- Yet To Do -----
# to do:
# Add cmd line parameter to generate default cfg file. (not needed)
# Add NAS mount parameters to JukeBox.cfg. install-Nas.py can read cfg to get
#  mount parameters. same for install-Dac.py, can get DAC type from cfg.
# Get Touch Screen working.
# Add ability to use SD card as a music source.

#------ Start of code -----

import sys
import os
import gc
import json
from os.path import join, getsize
import pygame as Pg
import random
import threading
import subprocess
import time
import pyudev
import evdev
from evdev import *

import RPi.GPIO as GPIO
import digitalio
import board
from digitalio import DigitalInOut, Direction, Pull

from gpiozero import CPUTemperature

Cpu = CPUTemperature()
print('CPU: ' + str(Cpu.temperature) + ' C')

Config = {
  "Remote": "HID_Remote01.txt",
  "Display": "ILI9341",
  "DAC": {"Type": "PCM5242",
          "Name": "IQaudIODAC",
         },
  "Pico": False
}

fn = 'jukebox.cfg'

# create the default jukebox.cfg file
#with open(fn, "w") as fp:
#  json.dump(Config, fp, indent=2)    # pretty printing

# a file access error will throw an exception and switch to the default values.
if os.path.exists(fn):
  print(fn + ' exists')

  try:
    with open(fn, 'r') as fp:
      Config = json.load(fp)

  except:
    print('Unable to load configuration json file: ' + fn)
    print('Using default configuration')

else:
  print(fn + ' does not exist')
  print('Using default configuration')

print('Remote: '  + Config['Remote'])
print('Display: ' + Config['Display'])
print('DAC: '     + Config['DAC']['Type'] + ', ' + Config['DAC']['Name'])
print('Pico: '    + str(Config['Pico']))

if Config['Pico'] == False:
  print('Control for MSGEQ7')

  #===== MSGEQ7 & ADS1015 support =====
  from ws2812 import WS2812
  from ws2812 import LedStrip
else:
  print('Control for Pico')

print('----------\n')

if Config['Remote'].endswith('.toml'):
  # IR remote in use
  # import this file if using an IR remote
  print('Using an IR remote')
  from ir_rc import Rc_device 
else:
  # import this file if using a Bluetooth remote.
  print('Using a Bluetooth remote')
  from bt_rc import Rc_device

#***********************************
Display = None
  
if Config['Display'].upper() == 'ILI9341':
  from tft_lcd import Tft_Lcd
  Display = Tft_Lcd()
  
elif Config['Display'].upper() == 'ST7789':
  from tft_lcd import Tft_Lcd
  Display = Tft_Lcd()
  
elif Config['Display'].upper() == 'LCD2004':
  from Lcd2004 import LcdDisplay
  # Create display object
  Display = LcdDisplay()
  
elif Config['Display'].upper() == 'SSD1306':
  import Adafruit_GPIO.SPI as SPI
  import Adafruit_SSD1306
  from PIL import Image
  from PIL import ImageDraw
  from PIL import ImageFont
#    Display = ??
else:
  print('No display selected')

#***********************************  
#if Config['DAC']['Type'].upper().startswith('RESPEAKER'):
  #---- ReSpeaker DotStar Support -----
  #import /mic_hat/interfaces/apa102.py
  #import apa102
  #try:
  #    import queue as Queue
  #except ImportError:
  #    import Queue as Queue

#----- 20x4 LCD Support ----
# If you are using the 2004LCD then uncomment the next line
#from Lcd2004 import LcdDisplay


#----- SSD1306 Support -----
# If using the SSD1306 OLED display uncomment these five lines
#import Adafruit_GPIO.SPI as SPI
#import Adafruit_SSD1306
#from PIL import Image
#from PIL import ImageDraw
#from PIL import ImageFont

#----- Global Constants -----
# VR Box MAC address, another simple BLE remote
#DevAddr = 'FF:FF:50:02:C9:6B'

# Air Mouse BLE 5.2 Remote MAC address, the chosen one
#DevAddr = 'FF:23:05:30:30:9C'       # RPiZ2W-168
#DevAddr = 'FF:23:05:30:30:2A'       # RPiZ2W-169

# BPR1S Remote, Classic Bluetooth (Boxput)
#DevAddr = 'CC:2F:C1:E9:84:C5'

#----- Global Constants -----
NASPATH = '/home/nas'
USBPATH = '/home/usb'
SDPATH  = '/home/music'

ADC_PIN  = 4      # ADS1115 IRQ pin
PEL_PIN  = 5      # MSGEQ7 Reset pin/Pico Enable LEDs
PNA_PIN  = 16     # MSGEQ7 Strobe pin/Pico Next Action
BTN_PIN  = 17     # Respeaker/Waveshare WM8960 button pin
TBTN_PIN = 24     # touch button pin


#----- Global Variables -----
Remote     = Rc_device(Config['Remote'])
IsPaused   = False
IsPowered  = True
DoGarbage  = False

UserVolume = 0.3

StopFlag   = False
UsbFlag    = False
TbtnFlag   = False

MusicPath = NASPATH
Artists = list()
Albums = list()
Songs = list()

if Config['Pico'] == False:
  NumPixels = 71
  Leds = None

#----- Setup USB event handler -----
context = pyudev.Context()
monitor = pyudev.Monitor.from_netlink(context)
monitor.filter_by('block')
#------------------------------------------------------------------------------

def setUsbFlag(state):
  global UsbFlag
  
  UsbFlag = state
  print('UsbFlag: ' + str(state))
  
# cannot do the umount here, system refuses umount due to drive being busy!  
def handle_usb_events(action, device):
  global Artists
  global Pg
  global MusicPath
  global USBPATH
  global Display
    
  # if device has a file system type it has to be a hard drive
  if 'ID_FS_TYPE' in device:
    print('Device event')
    print('{0} - {1}'.format(action, device.device_node))
    print('USB drive ' + str(device.action))
    if 'add' == device.action:
      cmd = 'sudo mount ' + str(device.device_node) + ' ' + USBPATH
      print(cmd)
      subprocess.run([cmd], shell=True)
      Pg.mixer.music.stop()
      Pg.mixer.music.unload()
      MusicPath = USBPATH
      setUsbFlag(True)
      print(UsbFlag)
    elif 'remove' == device.action:
      Pg.mixer.music.stop()
      Pg.mixer.music.unload()
      MusicPath = NASPATH
      setUsbFlag(True)
      print(UsbFlag)
      cmd = 'sudo umount ' + str(device.device_node)
      subprocess.run([cmd], shell=True)
      
#------------------------------------------------------------------------------

def progExit():
  Display.setBackLight(False)     # turn off TFT
  if Config['Pico'] == False:
    GPIO.output(PEL_PIN, GPIO.LOW)  # disable LEDs
    Leds.clear()
  else:
    GPIO.output(PEL_PIN, GPIO.LOW)  # disable LEDs
    
  time.sleep(0.1)   # wait for LEDs to turn off
  observer.stop()
  GPIO.cleanup()
  sys.exit()
#------------------------------------------------------------------------------

# Pass in value to change volume by. Negative values reduce volume.
def volumeKey(value):
  global UserVolume

  print('Volume')  
  UserVolume += value
  if UserVolume < 0.0:
    UserVolume = 0.0
  if UserVolume > 1.0:
    UserVolume = 1.0
    
  Pg.mixer.music.set_volume(UserVolume)
#------------------------------------------------------------------------------

# Rather than reducing the volume and continue to play, the muteKey function
# pauses play without affecting volume. Same as pauseKey.
# pause key will 'wake up' system from power off.
def pauseKey():
  global IsPaused
  global Pg

  Display.setRow(220)
  
  if IsPaused == True:
    Display.setBackLight(True)
    IsPowered = True  
    IsPaused = False
    if Config['Pico'] == True:
      GPIO.output(PEL_PIN, GPIO.HIGH)  # enable LEDs
    else:
      Leds.pause(False)
            
    Pg.mixer.music.unpause()
    Display.bottomRowClear()
    showSource()
    Display.show()
    print('Playing')
  else:
    IsPaused = True
    if Config['Pico'] == True:
      GPIO.output(PEL_PIN, GPIO.LOW)  # disable LEDs
    else:
      Leds.pause(True)
      Leds.clear()
      
    Pg.mixer.music.pause()
    Display.bottomRowClear()
    Display.bottomRow('Paused')
    Display.show()
    print('Paused')
#------------------------------------------------------------------------------

# Power key is alternate action. Cannot actually power down Pi, no way to wake
# it up. This simulates power down & instant power up.
def powerKey():
  global IsPowered
  global IsPaused
  global DoGarbage
  global Pg
  global Display
  
  if IsPowered:
    IsPowered = False  
    IsPaused = True

    # turn off backlight
    Display.setBackLight(False)

    # turn off the LEDs.
    if Config['Pico'] == True:
      GPIO.output(PEL_PIN, GPIO.LOW)    # disable LEDs
    else:
      Leds.pause(True)
      Leds.clear()
    
    Pg.mixer.music.pause()
    DoGarbage = True
    print('Power off')
  else:
    # turn on backlight
    Display.setBackLight(True)

    # re-enable LEDs
    if Config['Pico'] == True:
      GPIO.output(PEL_PIN, GPIO.HIGH)  # enable LEDs
    else:
      Leds.pause(False)
    
    IsPowered = True  
    IsPaused = False
    Pg.mixer.music.unpause()
    print('Power on')
#------------------------------------------------------------------------------

def rightKey():
  print('Right Key')

  # alternate action for LED_Disable_Pin, only for Pico  
  if Config['Pico'] == True:
    if GPIO.HIGH == GPIO.input(PEL_PIN):
      GPIO.output(PEL_PIN, GPIO.LOW)    # disable LEDs
      print('LEDs disabled')
    else:
      GPIO.output(PEL_PIN, GPIO.HIGH)   # enable LEDs
      print('LEDs enabled')
      
  # there is no action to take when Pico is not present
#------------------------------------------------------------------------------
  
def leftKey():
  print('Left Key')
#------------------------------------------------------------------------------

def downKey():
  print('Down Key')
#------------------------------------------------------------------------------
    
def upKey():
#  print('Up Key')
  print('Up Key, next LED action')
  if Config['Pico'] == False:
    Leds.reqActionChange()
  else:   
    GPIO.output(PNA_PIN, GPIO.HIGH)  # high pulse
##    time.sleep(0.0001)    # 100uS pulse
    GPIO.output(PNA_PIN, GPIO.LOW)  # finish the pulse
#------------------------------------------------------------------------------

def okKey():
  print('OK key')  
#------------------------------------------------------------------------------
  
def backKey():
  print('Back Key') 
#------------------------------------------------------------------------------
  
def homeKey():
  print('Home Key')
#------------------------------------------------------------------------------

def skipKey():
  global Pg
  
  print('Skip Key')
  Pg.mixer.music.stop()     # stop current playback, skips to next song
#------------------------------------------------------------------------------

def rewindKey():
  global Pg
  
  print('Rewind Key')
  Pg.mixer.music.rewind()   # replay same song from begining
#------------------------------------------------------------------------------
       
#==============================================================================
# Attempt to re-establish connection to the NAS server. Do this by requesting
# a directory listing.
#==============================================================================
def checkNAS(path):
  if NASPATH == path:
    count = 10
    while count > 0:
      try:
        # throws an exception of failure
        os.listdir(path)
        return
      except KeyboardInterrupt:
        # if user hits Ctrl/C then exit
        # (works only in console mode)
        print('ChkNas Keybd Int')
        progExit()
      except:
        count -= 1
        print('Re-connecting with NAS')
        subprocess.run(['sudo mount -a'], shell=True)
        time.sleep(0.5)       # wait 500mS
    # end while
    print('Failed to reconnect with NAS drive')
    progExit()
#------------------------------------------------------------------------------

#==============================================================================
# Starts streaming a file to the music player.
# This will handle loss of wifi error. does not handle missing file while NAS
# share is valid (ie connected).
#==============================================================================
def play_music(music_file):
    '''
    stream music with mixer.music module in blocking manner
    this will stream the sound from disk while playing
    '''
    t = 0;
    while t < 5:
      try:
        Pg.mixer.music.load(music_file)
        print("Music file {} loaded!".format(music_file))
        break;
      except Pg.error:
# this exception catches the error, but does not fix it !!
        print("File {} not found! {}".format(music_file, Pg.get_error()))

        # try to reconnect to the NAS share
        checkNAS(path)

        t = t + 1
      except:
        print('Unknown error')
        t = t + 1
          
    if t < 5:
      Pg.mixer.music.play()
#------------------------------------------------------------------------------

#==============================================================================
# Make a list of all Artists in the music directory.
#==============================================================================
def getArtists():
  global Artists
  
  Artists.clear()
  counter = 5
  
  while 0 == len(Artists) and counter > 0:
    counter -= 1
    try:
      if MusicPath == USBPATH:
        print(os.listdir(MusicPath))
        
      Artists = [item for item in os.listdir(MusicPath) if os.path.isdir(os.path.join(MusicPath, item))]
    except KeyboardInterrupt:
      print('getArtists() kybd exit')
      progExit()
    except:
      checkNAS(MusicPath)  

    if 0 == len(Artists):
      time.sleep(0.5)
  # end while      
#------------------------------------------------------------------------------

#==============================================================================
# Make a list of all Albums in the selected directory (Artist).
#==============================================================================
def getAlbums(path):
  global Albums
  
  Albums.clear()
  counter = 5
  
  while 0 == len(Albums) and counter > 0:
    counter -= 1
    try:
      Albums = [item for item in os.listdir(path) if os.path.isdir(os.path.join(path, item))]
      print (Albums)
      print (str(len(Albums)) + ' Albums Found\n')
    except:
      # no albums found
      checkNAS(MusicPath)

#------------------------------------------------------------------------------

#==============================================================================
# Make a list of all songs in the MP3 directory.
#==============================================================================
def getSongs(path):
  global Songs
  
  Songs.clear();
  counter = 5;
  
  # make sure the NAS share is available
  while 0 == len(Songs) and counter > 0:
    counter -= 1  
    try:
      print ('Creating list of songs')
      for path, dirs, files in os.walk(path):
        for name in files:
#          print('** ' + name)
          if name.lower().endswith('.mp3') or name.lower().endswith('.flac'):
            Songs.append(name)
      
      print ('List of Songs created')
      song = Songs[0]
      # if song starts with two numerics and a space then sort so they play in the
      # sequence as the original album.
      if (song[0].isnumeric() and song[1].isnumeric() and ' ' == song[2]):
        Songs.sort()

      print(Songs)
  #    print('Found ' + str(len(Songs) + ' songs\n')
    except:
      print('Error reading Songs')
      checkNAS(MusicPath)    
#------------------------------------------------------------------------------

#==============================================================================
# Show artist, album & song title on the display.
#==============================================================================
# seems to be BGR not RGB
ILI9341_BLACK       = 0x000000
ILI9341_BLUE        = 0xFF0000
ILI9341_RED         = 0x0000FF
ILI9341_GREEN       = 0x00FF00
ILI9341_CYAN        = 0xFFFF00
ILI9341_MAGENTA     = 0xFF00FF
ILI9341_YELLOW      = 0x00FFFF
ILI9341_WHITE       = 0xFFFFFF


def showArtist(artist, album, song):
##  global Display
  
  # show artist and album
  Display.clear()

  # define a box to write the Artist in
  Display.setRow(16)
  Display.textBox(Display.getRow(), ILI9341_WHITE, artist)
  if None != album:
    Display.textBox(Display.getRow(), ILI9341_GREEN, album)
  showSong(song)

#------------------------------------------------------------------------------
def showSong(song):
  print(song + '\n')
  str = song[:song.index('.')]
  if len(str) >= 3:
    # remove leading song number if present
    if (str[0].isnumeric() and str[1].isnumeric() and ' ' == str[2]):
      str = str[3:]
    
  print(str  + '\n')
  
  # show song title
  Display.textBox(Display.getRow(), ILI9341_RED, str)

  showTemperature()
  showSource()
  Display.show()
  
#------------------------------------------------------------------------------
def showSource():
  global MusicPath
  global USBPATH
  global NASPATH
  
  if MusicPath == USBPATH:
    source = 'USB'
  elif MusicPath == NASPATH:
    source = 'NAS'
    
  Display.bottomRow('Source: ' + source)

#------------------------------------------------------------------------------
def showTemperature():
  global Cpu
  
  txt = 'CPU: ' + str(Cpu.temperature) + ' C'
  print(txt)

  if Cpu.temperature < 50.0:
    color = ILI9341_BLUE
  elif Cpu.temperature < 65.0:
    color = ILI9341_GREEN
  else:
    color = ILI9341_RED
      
  Display.textBox(190, color, txt)
#  Display.show()
  
#==============================================================================
# Button Event Listener as a daemon thread (auto shutdown when program exits).
# Runs as a daemon thread (auto shutdown when program exits). Detects button
# press and release events. Cannot generate another press until released.
#==============================================================================
def buttonListener():
  global StopFlag
##  global Display
  
  flag = False
  print('Button Handler\n')
  while True:
    if False == flag:
      # stall waiting for pressed event
      button.wait_for_press()
      flag = True
      print('Button Pressed\n')
      # add button pressed action here
#      StopFlag = True
    else:
      # stall waiting for released event
      button.wait_for_release()
      flag = False
      print('Button Released\n')
      # add button released action here
#------------------------------------------------------------------------------

# The argument is the GPIO pin number that threw the event
def tbuttonListener(pin):
  global Leds
  
  if TBTN_PIN == pin:
    print('TButton pressed')
    if False == IsPowered:
      # power down the system
      powerKey()
    else:
      if Config['Pico'] == True:
        GPIO.output(PNA_PIN, GPIO.HIGH)  # high pulse
        GPIO.output(PNA_PIN, GPIO.LOW)
      else:
        Leds.reqActionChange()
  elif BTN_PIN == pin:
    print('Respeaker button pressed')
  elif ADC_PIN == pin:
    print('ADS Ready')
  else:
    print(str(pin) + ' signaled')
#------------------------------------------------------------------------------

VOLUME_STEP = 0.05

def volumeKeyDown():
  print('Volume Dn')
  volumeKey(-VOLUME_STEP)

def volumeKeyUp():
  print('Volume Up')
  volumeKey(VOLUME_STEP)
  
  
# Expand the dictionary to activate more buttons
KeyDict = {'113':pauseKey,        # KEY_MUTE
           '114':volumeKeyDown,   # KEY_VOLUMEDOWN
           '115':volumeKeyUp,     # KEY_VOLUMEUP
           '116':powerKey,        # KEY_POWER
           '164':pauseKey,        # KEY_PLAYPAUSE
           '106':rightKey,        # KEY_RIGHT
           '105':leftKey,         # KEY_LEFT
           '108':downKey,         # KEY_DOWN
           '103':upKey,           # KEY_UP
           '352':okKey,           # KEY_OK
           '158':backKey,         # KEY_BACK
           '102':homeKey,         # KEY_HOME
           '407':skipKey,         # KEY_SEARCH
           '412':rewindKey        # KEY_COMPOSE
           }

#==============================================================================
# Dispatch events received from the remote device.
# Use the event.code to invoke the function associated with the event.code.
#==============================================================================
def dispatch(event):
#  print('Dispatcher')
  if event.type == evdev.ecodes.EV_KEY:
    if event.value == 1:          # key down event
      try:
        # use the keycode to lookup the function to invoke, thows an exception
        # if no match found
        func = KeyDict[str(event.code)]
#        print('Function found')
        func()
      except KeyError:
        print('No function assigned to: ' + str(event.code))
#    else:
#      print('Not key down event')
#  else:
#    print('Not a key event')      
#------------------------------------------------------------------------------

def playSongs(album):
  global Artists
  global Songs
  global Pg
  global StopFlag
  global DoGarbage
  global gc
  
  # walk the list of songs, playing each in turn
  for song in Songs:
    # songs are either .mp3 or .flac
    if song.lower().endswith('.mp3') or song.lower().endswith('.flac'):
      # show info
      showArtist(Artists[artist], album, song)

      # play the song
      try:
        if album == None:
          songpath = path + '/' + song
        else:
          songpath = path + '/' + album + '/' + song
          
        play_music(songpath)
               
        # stall here waiting for the song to finish
        while Pg.mixer.music.get_busy() or IsPaused == True:
          # 30mS delay
          clock.tick(30)

          # call this periodically to handle received remote cmds
          if Remote.rcHasEvent():
            dispatch(Remote.rcGetEvent())

          # check for garbage collection request
          if True == DoGarbage:
            DoGarbage = False
            print('Collecting Garbage')
            gc.collect()
            print('Garbage collection finished')

          # check for button press, signals stop
          if StopFlag:
            # stop the program
            print('Stopping')
            Pg.mixer.music.fadeout(1000)
            Pg.mixer.music.stop()
            os.system('sudo reboot now')
#                raise SystemExit
        # end while
        
        # request LED action change
        if Config['Pico'] == False:
          Leds.reqActionChange()
        else:
          GPIO.output(PNA_PIN, GPIO.HIGH) # set next action high
          time.sleep(0.25)
          GPIO.output(PNA_PIN, GPIO.LOW) # finish pulse

        print('Next song')

        # exit songs for loop if Artists is empty
        if UsbFlag == True:
          print('UsbFlag is true')
          return
        else:
          print('UsbFlag is false')          

      except KeyboardInterrupt:
        print('main kybd exit')
        # if user hits Ctrl/C then exit
        # (works only in console mode)
        Pg.mixer.music.fadeout(1000)
        Pg.mixer.music.stop()
        progExit()
  # for Songs
#------------------------------------------------------------------------------

def changeMusicPath(path):
  global Pg
  global MusicPath
  
  Pg.mixer.stop()
  MusicPath = path
#------------------------------------------------------------------------------      

#==============================================================================
# Main program
#==============================================================================
import time
### from ws2812 import WS2812

global Pg
#global Leds

# seed the random number generator using current system time
random.seed()

# I am using rc.local to run this script on boot up. rc.local is run after the
# system has finished booting.

artist = 0
numArtists = 0

btnFlag = False

# set seeed-2mic-voicecard headphone volume to max in alsamixer
#subprocess.run(['amixer -c 1 -- sset Headphone 120'], shell=True)

# turn off auto wifi power off. this needs to be done everytime the script is
# run because linux sets power_save to on during start up. doing this appears
# to have 'fixed' the idle WiFi dropout issue.
subprocess.run(['sudo iw dev wlan0 set power_save off'], shell=True)

# This will ensure that the NAS drive is mounted
checkNAS(MusicPath)
#subprocess.run(['sudo mount -a'], shell=True)

# Create display object
Display = Tft_Lcd()

Display.clear()

if Config['Pico'] == False:
  # create thread for SK6812 & WS2812B control, use GPIO12, case has 71 LEDs.
  Leds = WS2812(NumPixels)

  # turn off all LEDs
  Leds.clear()

  # create the four virtual LED strips, default action is 'chaser'
  strip = LedStrip(Leds, 0, 25)
  strip.action(True)        # initialize default action
  Leds.addStrip(strip)

  strip = LedStrip(Leds, 25, 23)
  strip.action(True)
  Leds.addStrip(strip)

  strip = LedStrip(Leds, 48, 10)
  strip.action(True)
  Leds.addStrip(strip)

  strip = LedStrip(Leds, 58, 13)
  strip.action(True)
  Leds.addStrip(strip)

#----- GPIO setup -----
GPIO.setmode(GPIO.BCM)      # use BCM pinout

if Config['Pico'] == False:
  # setup ADS1115 irq pin to detect fallinging edge events, ADS ready
  GPIO.setup(ADC_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)
  GPIO.add_event_detect(ADC_PIN, GPIO.FALLING, callback=tbuttonListener, bouncetime=100)

# setup Touch Button to detect rising edge events, button press
GPIO.setup(TBTN_PIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.add_event_detect(TBTN_PIN, GPIO.RISING, callback=tbuttonListener, bouncetime=100)

# Respeaker board button is hard wired to GPIO17
# setup respeaker Button to detect falling edge events, button press
GPIO.setup(BTN_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.add_event_detect(BTN_PIN, GPIO.FALLING, callback=tbuttonListener, bouncetime=100)

# setup Pico interface pins as outputs.
GPIO.setup(PEL_PIN, GPIO.OUT)
GPIO.output(PEL_PIN, GPIO.HIGH)  # enable Pico LEDs

GPIO.setup(PNA_PIN, GPIO.OUT)
if Config['Pico'] == False:
  GPIO.output(PNA_PIN, GPIO.HIGH) # set strobe high
else:
  GPIO.output(PNA_PIN, GPIO.LOW) # set strobe low

#----- USB auto mount -----
# If present on boot up then get music from the USB device otherwise get music
# from the NAS device
# before we can auto mount a USB device, we must determine it's path
# create a list of all block devices with a partition
print('\n*****')
context = pyudev.Context()
for device in context.list_devices(subsystem='block', DEVTYPE='partition'):
  print(device)
  if str(device.device_node).find('/dev/sd') > -1:
    # try to mount the USB device
    cmd = 'sudo mount ' + str(device.device_node) + ' ' + USBPATH
    print('Trying ' + str(device.device_node))
    result = subprocess.run([cmd], shell=True)
#    print(result)
    if str(result).find('returncode=0') > -1:
      print('USB Device ' + str(device.device_node) + ' mounted')
      # try to get music from USB device
      MusicPath = USBPATH
      break;
    
    if str(result).find('returncode=32') > -1:
      print('USB Device ' + str(device.device_node) + ' already mounted')
      # try to get music from USB device
      MusicPath = USBPATH
      break;
print('*****\n')

# observer catches interesting events and passes them to our handler
# we are looking for USB 'add' & 'remove' events   
observer = pyudev.MonitorObserver(monitor, handle_usb_events)
observer.start()

# Audio stuff runs on main thread

# setup pygame mixer
freq = 44100    # audio CD quality
bitsize = -16   # unsigned 16 bit
channels = 2    # 1 is mono, 2 is stereo
buffer = 2048   # number of samples (experiment to get right sound)

# this no longer is required with pygame 2.x
# the name has to match name shown by aplay -l
# waveshare audio hat uses same driver as respeaker board
#devicename = 'seeed-2mic-voicecard'   # select Respeaker DAC for playback
#devicename = 'BossDAC'   # select Allo Boss DAC for playback
#devicename = 'BossDAC'   # Inno-Maker PCM512x DAC for playback
#devicename = 'snd_rpi_hifiberry_dac'   # Generic I2S PCM5102
#devicename = 'IQaudIODAC'

devicename = Config['DAC']['Name']
print('Device Name: ' + devicename)

# initialize the pygame mixer for stereo using the chosen DAC
try:
  Pg.mixer.init(freq, bitsize, channels, buffer, devicename=Config['DAC']['Name'])
  print('Using audio device: ' + devicename)
except Pg.error as err:
  print(devicename + ' not found err, try again')
  print('  ' + str(err))
  try:
    Pg.mixer.init(freq, bitsize, channels, buffer)
    print('Mixer is using default audio device')
  except Pg.error as errr:
    print('* ' + str(errr))
    progExit()
  
UserVolume = 0.3
print("Playing at volume: " + str(UserVolume)+ "\n")
Pg.mixer.music.set_volume(UserVolume)

clock = Pg.time.Clock()

# The player works as follows; The music folder is organized as artist/albums/songs.
# We make a list of all artists. This list is never destroyed. An artist is randomly
# selected from the list. A list of Albums by the selected artist is created. We
# walk the list, making a list of songs from the selected album. We walk the list
# of songs playing each in turn. When there are no more songs to play, the next
# album in the list of albums is selected and all the songs are played. When we
# run out of albums by the selected artist then a new artist is selected and the
# process repeats.

# When end of list is reached then it repeats.

# forever loop
while True:
  # create a list of Artists. if present then use USB. default is NAS.
  while True:
    getArtists()
    print(str(len(Artists)) + ' found\n')
    
    if len(Artists) == 0:
      if MusicPath == USBPATH:
        print ('No music files found on USB device\n')
        MusicPath == NASPATH
      else:
        print ('No music files found on NAS device\n')
        progExit()
    else:
      break
  
  print(str(len(Artists)) + ' found')
  numArtists = len(Artists) - 1  
  while numArtists >= 0:
    if UsbFlag == False:
      # randomly select an Artist
      artist = random.randint(0, numArtists)
      path = MusicPath + '/' + Artists[artist]
      print(Artists[artist])
      print(path)
      getAlbums(path)

      print('Num Artists: ' + str(numArtists))
      if 0 == len(Albums):
        # no albums, try to create list of songs
        album = None
        getSongs(path)
        if len(Songs) > 0:
          playSongs(album)
      else:
        # iterate through the albums
        for album in Albums:
          # create a list of songs in the album
          getSongs(path + '/' + album)
          if len(Songs) > 0:
            playSongs(album)
            
          if UsbFlag == True:
            break
        # for Albums

      # done playing all albums/songs by the artist, move the artist to the end of the list
      a = Artists.pop(artist)
      Artists.append(a)
      numArtists -= 1
    else:
      numArtists -= 1
      setUsbFlag(False)
  # while numArtists > 0
# while True
#------------------------------------------------------------------------------

