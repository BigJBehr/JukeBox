#!/usr/bin/python3

# This class is for a Bluetooth remote control device that is derived from my
# RemotControlDevice class. I am using this remote to control a music player.
# This script has been tested with a Bluetooth Classic (EDR) remote and a BLE
# remote. The remote device must be paired for this to work. Bluetooth Classic
# remotes usually have a button combination that puts them in pairing mode. BLE
# remotes are always ready to pair, as long as they have not powered down to save
# power.

# Remote control is achieved with a combo BLE and IR learning remote. This script
# uses the remote's BLE mode.
# The Air Mouse BLE 5.2 Remote was chosen because it uses BLE and the buttons
# are labeled as a simple audio device remote. Also it was inexpensive. If the 
# Air Mouse is not paired it will transmit BLE and IR when a buton is pressed.
# Once paired, the remote will only send BLE. When paired the keycodes received
# on the input device are almost the same as what is expected by the main thread.
# All Bluetooth remote control devices are low energy devices. A Bluetooth remote
# will shutdown if it is inactive for a preset period of time. When you pick up
# any Blutooth remote that has been sitting idle, you may need to press a key or
# two to wake it up.

#===== Find Your Device =====
# To test for nearby Bluetooth devices and reveal their MAC addresses,
# type; sudo bluetoothctl
# type; scan on

# At a minimum, you should see the MAC address & name of the Bluetooth Controller
# that is built-in or plugged into a USB port. The MAC address and name of your
# Bluetooth device should also appear. If you can find your device good. If not
# try pressing buttons on the remote to 'wake it up'.
# To start a new scan, you must first end the current scan.
# type; scan off
# Now start a new scan, but first make sure your remote is 'awake'
# type; scan on
# Now you can pair your Bluetooth remote with your RPi.
# type; trust xx:xx:xx:xx:xx:xx 
# Where xx:xx:xx:xx:xx:xx is the MAC address of your remote
# When your remote is trusted, you can pair it by
# type; pair xx:xx:xx:xx:xx:xx 
# Once paired you can exit bluetoothctl by
# type; exit

#===== Python Setup =====
# Install pip3. Needed for adding Python3 librarys
# type; sudo apt install python3-pip -y

#===== Power Button =====
# The keycode sent by the power button on my remote is assigned to 'KEY_POWER'
# in the HID_Remote01.txt file. When the power button is pressed the system decodes
# 'KEY_POWER' as a command to shutdown the RPi system. If you do not want this
# behavior, you have two options. First, edit your .txt file and assign the
# keycode to a different 'KEY_xxx'. Or, edit /etc/systemd/logind.conf. Find the
# line; '#HandlePowerKey=poweroff'. Add a line after this one;
# 'HandlePowerKey=suspend'. Reboot, now the power button works like any other
# button.


# 7-2-24  - Working as a paired BLE device. Works same as Classic & IR.

# 7-3-24  - Converted to use new base class for remote control devices

# 7-4-24  - This works for BLE.

# 7-5-24  - Added a way out of the inner while loop when an error occurs. The
#         - exit provided forces the code back to looking for valid input devices.
#         - Modified to load remote information from a file. Filename is passed
#         - as cmd line argument.

# 7-7-24  - Fixed issues with loading json info files. Was improper formatting.

# 7-9-24  - Commented out some debug statements.

#===== Start the of Script ====================================================
from abc import ABC, abstractmethod

import time
import threading
import evdev
import json
import sys
import os

try:
  import queue as Queue
except ImportError:
  import Queue as Queue

from RemoteControlDev import RemoteControlDev

# The code here is generic and should work with any paired Bluetooth remote.
# All you need to do is to create edit the KeyXlate dictionary to tailor it to
# your remote. 

# Device names used by my AirMouse BLE 5.2 Remote. All of these remotes use the
# same names. Use the MAC address to determine which remote is which.
#BtRemoteKeybd = 'HID Remote01 Keyboard'
#BtRemoteMouse = 'HID Remote01 Mouse'

#BtRemoteKeybd = 'BOXPUT | BPR1S Keyboard'
#BtRemoteMouse = 'BOXPUT | BPR1S Mouse'

# Create a dictionary of key:value pairs to translate remote keycodes to system
# event keycodes. First column must be a string with the actual keycode from the
# remote, stored as decimal, not hex. second colunm is a number that corresponds
# to the keycodes the main script is looking for. Edit this table to match your
# remote.

# This is the default remote device information
xxBpr1sRemote = {'Keybd': 'BOXPUT | BPR1S Keyboard',
            'Mouse': 'BOXPUT | BPR1S Mouse',
            'Keys': {'116':116,      # KEY_POWER
                     '103':103,      # KEY_UP
                     '108':108,      # KEY_DOWN
                     '105':105,      # KEY_LEFT
                     '106':106,      # KEY_RIGHT
                     '353':352,      ## KEY_ENTER -> KEY_OK
                     '14' :158,      # KEY_BACK
                     '113':113,      # KEY_MUTE
                     '158':139,      ## KEY_MENU
                     '114':114,      # KEY_VOLUMEDOWN
                     '115':115,      # KEY_VOLUMEUP
                     '164':164,      # KEY_HOMEPAGE -> KEY_HOME
                     '172':164,      # KEY_PLAYPAUSE
                     '127':412,      # KEY PREVIOUSSONG -> KEY_PREVIOUS
                     '217':407,      # KEY_NEXTSONG -> KEY_NEXT
                    },
}   # end Bpr1sRemote

Bpr1sRemote = {
  "Keybd": "HID Remote01 Keyboard",
  "Mouse": "HID Remote01 Mouse",
  "Keys": {
    "116": 116,
    "103": 103,
    "108": 108,
    "105": 105,
    "106": 106,
    "28": 352,
    "158": 158,
    "113": 113,
    "139": 139,
    "114": 114,
    "115": 115,
    "172": 102,
    "164": 164,
    "165": 412,
    "163": 407,
  },
}

# class that encapsulates an IR remote using RemoteControlDev as the base class
class Rc_device(RemoteControlDev):
  def __init__(self, fn):
    self.flag = True
    self.btRemote = {}
      
#    with open("BPR1S.txt", "w") as fp:
#      json.dump(self.btRemote, fp, indent=2)    # pretty printing

    # a file access error will throw an exception and switch to the default
    # values
    if os.path.exists(fn):
      print(fn + ' exists')

      try:
        with open(fn, 'r') as fp:
          self.btRemote = json.load(fp)

        print(self.btRemote['Keybd'])
        print(self.btRemote['Mouse'])
        print(self.btRemote['Keys'])

      except:
        print('Unable to load remote json file: ' + fn)
        print('Using default remote info')
        self.btRemote = Bpr1sRemote

    else:
      print(fn + ' does not exist')
      print('Using default remote info')
      self.btRemote = Bpr1sRemote
      
    # this starts the rcListener thread, moving to after loading remote info
    # helps to prevent 'no input device found' errors
    RemoteControlDev.__init__(self)

                  
  #----------------------------------------------------------------------------      

  # Translate the keycode from the remote to a system keycode and return it.
  def rcTranslate(self, kcode):
#    print('Translating')
#    print('Key code: ' + hex(kcode) + ', ' + str(kcode))
#    print('-----')
    # lookup keycode & return system key code
    try:
#      print('Keycode: ' + hex(kcode) + ', ' + str(kcode))
      syskey = self.btRemote['Keys'][str(kcode)]
#      print('Sending ' + str(syskey))
      return(syskey)
    except KeyError:
      print('No match found for: ' + str(kcode))

    return kcode
#------------------------------------------------------------------------------      
  # this should be in it's own thread. received key events are pushed into a FIFO.
  # events are popped by the main thread and dispatched.

  # Bluetooth remote controllers run on batteries. In order to conserve battery
  # power, Bluetooth remotes will power down the radio and other hardware. Due
  # to this, the RPi will lose contact with the remote after a while. Therefore
  # a robust Bluetooth system should be able to gracefully handle losing the
  # remote and attempt to re-acquire it. Outer while loop is for reconnection.
  # inner while waits for key events, translates the event code and then forwards
  # the event to the foreground loop for processing.

  # This is the thread that blocks until a command from the remote is received.
  # If this is a key event then push it into the fifo.
  def rcListener(self):
    while True:
      # set the Bluetooth input device path
      if True == self.rcSetPath(self.btRemote['Keybd'], self.btRemote['Mouse']):
#        print('** Bluetooth remote connected **')
        self.flag = True
        
        #prints out device info at start
#        print(self.kybd)

        while True:
          try:
            # evdev takes care of polling the controller in a loop
            # stalls here waiting for remote key events
            event = self.kybd.read_one()
            if (event):
              # an event has occurred
              if event.type == evdev.ecodes.EV_KEY:  
                # the event is a key press event
#                print('Code: ' + str(event.code))      # key code
#                print('Value: ' + str(event.value))    # 0 -> down, 1 -> up, 2 -> held
                # push the key event into the fifo. this will block until room.
                event.code = self.rcTranslate(event.code)
                self.fifo.put(event)

          except KeyboardInterrupt:
            print('BT keybd exit')
            # exit thread loop on ^C
            #raise SystemExit
            sys.exit()
            
          except:
            # this happens when the remote disconnects
#            print('rcListener threw an exception')
            # exit inner while, try to re-acquire the remote
            break
        # end while
      else:
        if True == self.flag:
#          print('** BT remote has disconnected **')
          self.flag = False
          
      # wait 1/2 second then try to reconnect
      time.sleep(0.500)     # yeild for 500mS
    # end while
  #----------------------------------------------------------------------------    
#---- class end ---------------------------------------------------------------

