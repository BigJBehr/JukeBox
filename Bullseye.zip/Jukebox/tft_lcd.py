
#  7-20-24 - Modified to use either ILI9341 ot ST7789 320x240 LCD displays

#  7-22-24 - Modified to free up GPIO12 to use for WS2812 driver. Reset moved
#          - to GPIO23.

# 10-24-24 - Added touch, DC moved to GPIO22, MISO is GPIO9, TCS is GPIO7,
#            TIRQ is GPIO20.

# 11-26-24 - Added backlight control function.

# 12-23-24 - Changed background color to black.

import RPi.GPIO as GPIO
import digitalio
import board
from PIL import Image, ImageDraw, ImageFont

# First define some constants to allow easy resizing of shapes.
BORDER = 20
FONTSIZE = 24

# select display driver. 
ILI9341 = True

if True == ILI9341:
  from adafruit_rgb_display import ili9341
else:
  from adafruit_rgb_display import st7789  # pylint: disable=unused-import

class Tft_Lcd():
  def __init__(self):
    self.width = 0
    self.height = 0
    # Configuration for CS and DC pins (these are PiTFT defaults):
#    cs_pin = digitalio.DigitalInOut(board.CE0)
    cs_pin = digitalio.DigitalInOut(board.CE1)
    dc_pin = digitalio.DigitalInOut(board.D22)
    reset_pin = digitalio.DigitalInOut(board.D23)

    # touch pins
#    tcs_pin = digitalio.DigitalInOut(board.CE0)
#    self.tcs_pin.direction = digitalio.Direction.OUTPUT
#    self.tcs_pin.DriveMode = digitalio.DriveMode.PUSH_PULL
#    self.tcs_pin.value = True
#    tirq_pin = digitalio.DigitalInOut(board.D20)

#    self.tirq_pin.direction = digitalio.Direction.INPUT


    # Backlight pin is GPIO13 configure and turn on the backlight.
    self.bkled = digitalio.DigitalInOut(board.D13)
    self.bkled.direction = digitalio.Direction.OUTPUT
    self.bkled.DriveMode = digitalio.DriveMode.PUSH_PULL
    self.bkled.value = True
    
    # Setup SPI bus using hardware SPI:
    spi = board.SPI()

    # create diplay object
    if True == ILI9341:
      # changing BAUDRATE had no noticable change in SPI speed
      BAUDRATE = 24000000   # 24MHz 
#      BAUDRATE = 80000000   # 80MHz 
      self.disp = ili9341.ILI9341(spi, rotation=90,  # 2.2", 2.4", 2.8", 3.2" ILI9341
        cs=cs_pin, dc=dc_pin, rst=reset_pin, baudrate=BAUDRATE)

    else:    
      BAUDRATE = 80000000 
      # Alternate IPS display
      # The ST7789 240x320 displays that I own have rounded corners. This becomes
      # an issue when attempting to use the full width of 320 as only about 280 are
      # usable.
      self.disp = st7789.ST7789(spi, height=320, width=240, rotation=90,  # 1.3", 1.54" ST7789
                         cs=cs_pin, dc=dc_pin, rst=reset_pin, baudrate=BAUDRATE)

    # set sizes based on rotation
    if self.disp.rotation % 180 == 90:
        self.height = self.disp.width  # we swap height/width to rotate it to landscape!
        self.width = self.disp.height
        self.viewX = 320
        self.viewXoffset = 0
    else:
        self.width = self.disp.width  # we swap height/width to rotate it to portrait!
        self.height = self.disp.height
        self.viewX = 280
        self.viewXoffset = (self.width - self.viewX) / 2

    # Create blank image for drawing.
    # Make sure to create image with mode 'RGB' for full color.
    self.image = Image.new("RGB", (self.width, self.height))

    # Get drawing object to draw on image.
    self.draw = ImageDraw.Draw(self.image)

    # Load a TTF Font
    self.font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", FONTSIZE)
    
    (font_width, font_height) = self.font.getsize('test')
    self.rowStep = font_height
    self.row = 0

    print('Display is: ' + str(self.disp.width) + 'x' + str(self.disp.height))
    print('View is: ' + str(self.viewX) + 'x' + str(self.height))
    
  #----------------------------------------------------------------------------
    
  def textBox(self, row, color, artist):
    self.row = row
    self.write(color, artist)
    
  #----------------------------------------------------------------------------
  def write(self, color, strin):
    vx = 6
    print('==========')
    print(strin + ', length: ' + str(len(strin)))
    (fw, fh) = self.font.getsize(strin)
    if fw > self.viewX - vx:
      # line is too long

      # find the space character closest to self.width without exceeding it.      
      p = strin.find(' ')
      print(str(p) + ', ' + str(len(strin[:p])))
      
      while p > 0 and p <= len(strin):
        (fw, fh) = self.font.getsize(strin)
        if fw <= self.viewX - vx:
          # string fits on screen, show it
          break
        else:
          # too long
          p = strin.find(' ', p + 1, len(strin))
          print('> ' + str(p) + ', ' + str(len(strin)))
          (fw, fh) = self.font.getsize(strin[:p - 1])

          if fw < self.viewX - vx:
            # save position & find next space
            pls = p
          else:
            # show line up to last space (pls)
            print('Show line: ' + str(pls))
            print(strin[:pls])
            (fw, fh) = self.font.getsize(strin[:pls])
            self.draw.text((self.viewX // 2 - fw // 2, self.row),
                  strin[:pls], font = self.font, fill = color,)
            self.row += self.rowStep
            strin = strin[pls:]
            print('New strin:' + strin)            
      # end while
    # end if
    
    print('line fits')  
    (fw, fh) = self.font.getsize(strin)
    self.draw.text((self.viewXoffset + (self.viewX // 2) - (fw // 2), self.row), strin,
                     font = self.font, fill = color,)
    # Display image.
#    self.show()
    
    self.row += self.rowStep
    if self.row >= self.height:
      self.row = 0
  #----------------------------------------------------------------------------

  def show(self):
    self.disp.image(self.image)
    
  #----------------------------------------------------------------------------

  def clear(self):
    # blue background
    self.draw.rectangle((0, 0, self.width, self.height), fill=(0, 0, 0))
    self.disp.image(self.image)
    self.row = 0
  #----------------------------------------------------------------------------

  def setRow(self, row):
    self.row = row

  def getRow(self):
    return self.row

  def bottomRow(self, txt):
    (font_width, font_height) = self.font.getsize(txt)
    r = self.height - font_height

    if len(txt) > 0:
      m = self.row
      self.row = r
      self.write(0xFFFF00, txt)
      self.row = m
    else:
      print('erase row')
      # erase row
      self.draw.rectangle((0, r, self.width, self.height), fill=(0, 0, 0))
      self.disp.image(self.image)
    
  def bottomRowClear(self):        
    print('erase row')
    # erase row
    (font_width, font_height) = self.font.getsize('p')
    r = self.height - font_height
    self.draw.rectangle((0, r, self.width, self.height), fill=(0, 0, 0))
    self.disp.image(self.image)
  #----------------------------------------------------------------------------

  def setBackLight(self, state):
    self.bkled.value = state
  #----------------------------------------------------------------------------
  
  def test(self):
    # Draw a green filled box as the background
    self.draw.rectangle((0, 0, self.width, self.height), fill=(0, 255, 0))
    self.disp.image(self.image)

    # Draw a smaller inner purple rectangle
    self.draw.rectangle(
        (BORDER, BORDER, self.width - BORDER - 1, self.height - BORDER - 1), fill=(170, 0, 136)
    )

    # Draw Some Text
    text = "Hello World!"
    (font_width, font_height) = self.font.getsize(text)
    self.draw.text(
        (self.width // 2 - font_width // 2, self.height // 2 - font_height // 2),
        text,
        font = self.font,
        fill = (255, 255, 0),
    )

    # Display image.
    self.disp.image(self.image)
  #----------------------------------------------------------------------------
#----- end class --------------------------------------------------------------


