/**
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

// Art Deco Jukebox LED string driver.                  10-25-24

// 10-28-24 The ADC is able to read the MSGEQ7 chip.
//          Changed the LED drive to be called by a repeating timer. This means that the LED drive is running
//           in the background, no main loop involvement.
// 11-5-24  Changed to use DMA to copy the Pixels buffer to the PIO.
//          First three actions are working.
//          Removed all work from ISRs, now done in main loop.
// 11-22-24 RPi can now chage actions and blank the LED display.
//          Top button works great.
// 12-2-24  Changed LED disable signal to disable when low.
//  2-1-25  Added several LED actions based on music. Combo fades & fades mostly.
//          Removed Touch sw input, Now wired to RPi.
//  4-18-25 Fixed Fade. Added interrupt handler for Next_Action GPIO pin to change action. Fixed Random to use
//          all pixels.

// ===== to do =====
// need communications with JukeBox RPi, serial should work. send; end-of-song, pause, resume, pattern select, etc.


#include <stdio.h>
#include <stdlib.h>

#include "pico/stdlib.h"
#include "hardware/dma.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"
#include "hardware/gpio.h"
#include "hardware/uart.h"
#include "hardware/adc.h"
#include "ws2812.pio.h"

/**
 * NOTE:
 *  Take into consideration if your WS2812 is a RGB or RGBW variant.
 *
 *  If it is RGBW, you need to set IS_RGBW to true and provide 4 bytes per 
 *  pixel (Red, Green, Blue, White) and use urgbw_u32().
 *
 *  If it is RGB, set IS_RGBW to false and provide 3 bytes per pixel (Red,
 *  Green, Blue) and use urgb_u32().
 *
 *  When RGBW is used with urgb_u32(), the White channel will be ignored (off).
 *
 */
#define IS_RGBW         false
#define NUM_PIXELS      71          // from 60LEDS / meter strips

#ifdef PICO_DEFAULT_WS2812_PIN
#define WS2812_PIN PICO_DEFAULT_WS2812_PIN
#else
// default to pin 2 if the board doesn't have a default WS2812 pin defined
#define WS2812_PIN      2
#endif

#define BAUDRATE        115200

//#define LED_PIN         2           // WS2812B drive pin
//#define SW_PIN              3           // Touch sensor input pin
#define RST_PIN             4           // MSGEQ7 reset pin
#define STB_PIN             5           // MSGEQ7 strobe pin
#define NEXT_ACTION_PIN     6           // End of song, change action pulse
#define LEDS_DISABLE_PIN    7           // 0 => run Leds, 1 => Leds off

#define SMPSMODE_PIN        23          // set high to reduce PS ripple
#define BUILTIN_LED_PIN     25          // built-in LED pin

#define OUTMASK             0x02800030  // Rst, stb, SMPSMODE_PIN & BUILTIN_LED_PIN  are outputs
#define ADC_PIN             26          // read MSGEQ7 using A0/GPIO26

#define SW_MASK             (GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL)

#define NUM_FREQ            7

#define LED_DMA_IRQ             DMA_IRQ_0
#define LED_DMA_CHANNEL         (0)          // bit plane content DMA channel
#define LED_DMA_CHANNEL_MASK    (1u << LED_DMA_CHANNEL)

// Colors are defined as GRBW, shifted out MSB first.
// WS6812 uses GRBW format
#define GREEN       0xFF000000
#define RED         0x00FF0000
#define YELLOW      (GREEN | RED)
#define BLUE        0x0000FF00
#define CYAN        (GREEN | BLUE)
#define PURPLE      (BLUE | RED)
#define WHITE       (BLUE | RED | GREEN)
#define ORANGE      0x25FF0000      // gamma corrected half green + full red
#define VIOLET      0x005AFF00      // gamma corrected ~3/4 red + full blue
#define LTGREEN     0xFF5A0000      // gamma corrected ~3/4 red + full green
//#define TEAL        0xFF001100
//#define XXXX        0x25FF2500
#define BLACK       0x00000000

const uint32_t ColorTable[] = {GREEN, RED, YELLOW, BLUE, CYAN, PURPLE, WHITE,
                               ORANGE, VIOLET, LTGREEN};
#define MAXCOLORS   (sizeof(ColorTable) / sizeof(uint32_t))

// this enum matches the order in the color table
enum
{
    Green = 0,
    Red,
    Yellow,
    Blue,
    Cyan,
    Purple,
    White,
    Orange,
    Violet,
    LtGreen,
    NumColors
} Colors;

// gamma correction table.
const uint8_t Gamma8[] = {
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1,  1,  1,  1,
    1,  1,  1,  1,  1,  1,  1,  1,  1,  2,  2,  2,  2,  2,  2,  2,
    2,  3,  3,  3,  3,  3,  3,  3,  4,  4,  4,  4,  4,  5,  5,  5,
    5,  6,  6,  6,  6,  7,  7,  7,  7,  8,  8,  8,  9,  9,  9, 10,
   10, 10, 11, 11, 11, 12, 12, 13, 13, 13, 14, 14, 15, 15, 16, 16,
   17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 24, 24, 25,
   25, 26, 27, 27, 28, 29, 29, 30, 31, 32, 32, 33, 34, 35, 35, 36,
   37, 38, 39, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 50,
   51, 52, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 66, 67, 68,
   69, 70, 72, 73, 74, 75, 77, 78, 79, 81, 82, 83, 85, 86, 87, 89,
   90, 92, 93, 95, 96, 98, 99,101,102,104,105,107,109,110,112,114,
  115,117,119,120,122,124,126,127,129,131,133,135,137,138,140,142,
  144,146,148,150,152,154,156,158,160,162,164,167,169,171,173,175,
  177,180,182,184,186,189,191,193,196,198,200,203,205,208,210,213,
  215,218,220,223,225,228,231,233,236,239,241,244,247,249,252,255 };

const uint32_t FadeSteps[] = {
    0x00000100, 0x00010000, 0x00010100, 0x01000000, 0x01000100,
    0x01010000, 0x01010100
};
  
// The system uses four LED strips wired as one continuous strip. Only one GPIO
// pin is required to drive the entire strip. A PIO state-machine is used to
// wiggle out the bit timings for WS2812B & SK6812 LEDs. The software breaks
// the full strip into four virtual strips. Each virtual strip represents one
// of the four areas of the JukeBox that can light up.

// A PIO state machine (SM) is setup to drive a GPIO pin and to create a WS2812
// bit pattern for each of the 24 color bits. The SM is fed by a four word FIFO.
// To send data to the LED strip, just save 32 bit words to the PIO channel's 
// FIFO. A DMA channel is setup to feed the PIO channel's FIFO automatically
// when started.

// Simply fill the Pixels array with the pattern you want to display and then
// start the DMA channel. The LED strip is automatically updated with no CPU
// cycles used. The update takes about 2.2mS.

// storage for the pixels. a four byte (uint32_t) is used to hold the 24 bits
// used by each pixel. this is the entire strip.
volatile uint32_t Pixels[NUM_PIXELS];


volatile bool LedTimer_fired = false;

// these hold current action function table index & direction
volatile int Pat;
volatile int Dir;
volatile bool NewAction = false;
volatile bool DoAction = false;

struct repeating_timer LedTimer;        // LED rate-of-change timer

typedef union
{
    uint32_t    color;
    struct
    {
        uint8_t b;
        uint8_t r;
        uint8_t g;
        uint8_t w;
    } wgrb;
} Color_t;

// The LED string is single string of 71 LEDs.
// The LED string is sub-divided into four strings; the outer, inner, middle & top chamber.
typedef struct
{
    uint32_t    delay;      // pixel change delay
    uint16_t    cctimer;    // color change timer
    uint        pos;        // current pixel position
    uint        first;      // position of begining of virtual pixel strip
    uint        last;       // position of last pixel in strip
    uint        x;          // extra var
    int         dir;        // direction & step
    uint8_t     r;          // color table index
    uint8_t     g;
    uint8_t     b;
} LED_STR_T;   //  struct

#define NUMLEDSTRIPS       4
// storage for the virtual LED strips
LED_STR_T   Leds[] =
    {
        {5, 0, 0, 0, 24, 0, 1, 255, 0, 0},     // outer string
        {5, 0, 25, 25, 47, 0, 1, 0, 0, 255},   // inner string
        {5, 0, 48, 48, 57, 0, 1, 0, 255, 0},   // middle string
        {5, 0, 58, 58, 71, 0, 1, 255, 255, 0}  // top chamber string
    };

// storage for frequency data from the MSGEQ7 via the ADC 
uint16_t Data[NUM_FREQ];

// Read the ADC channel and store the value in an array.
void adcRead(void)
{
//    puts("Reading ADC\n");
    gpio_put(RST_PIN, true);
    gpio_put(STB_PIN, true);

    sleep_us(20);
    gpio_put(STB_PIN, false);
    sleep_us(55);
    gpio_put(STB_PIN, true);
    gpio_put(RST_PIN, false);
    sleep_us(75);

    for (int i = 0; i < NUM_FREQ; i++)
    {
        gpio_put(STB_PIN, false);
        // min settle time is 36uS. the longer the settle time the
        // more accurate the ADC reading will be.
        sleep_us(70);

        Data[i] = adc_read();
        gpio_put(STB_PIN, true);
        sleep_us(10);
    }   //  for
}   //  adcRead

// Convert three bytes into a 32 bit RGB color value.
static inline uint32_t ugrb_u32(uint8_t r, uint8_t g, uint8_t b)
{
    return
            ((uint32_t) (r << 16) |
             (uint32_t) (g << 24) |
             (uint32_t) (b << 8));
}   //  ugrb_u32

static inline uint32_t gammaCorrection(uint8_t r, uint8_t g, uint8_t b)
{
    return  ((uint32_t) (Gamma8[r] << 16)  |
             (uint32_t) (Gamma8[g] << 24) |
             (uint32_t) (Gamma8[b] << 8));
}   //  gammaCorrection

void fillPixels(uint32_t color)
{
    for(int i = 0; i < NUM_PIXELS; i++)
        Pixels[i] = color;
}   //  fillPixels

// start the DMA transfer to the PIO.
void showPixels(void) 
{
    if (dma_channel_is_busy(LED_DMA_CHANNEL))
        dma_channel_wait_for_finish_blocking (LED_DMA_CHANNEL);

    dma_channel_set_read_addr(LED_DMA_CHANNEL, Pixels, false);
    dma_channel_set_trans_count(LED_DMA_CHANNEL, NUM_PIXELS, true);
}   // showPixels


//===== LED Actions, all action functions need to be re-entrent and have same signature =====

uint actionChaser(LED_STR_T *ptr, int t)
{
    ptr->cctimer++;
    if (ptr->cctimer >= 500)
    {
        ptr->cctimer = 0;
        ptr->r++;
        if (ptr->r >= MAXCOLORS)
            ptr->r = 0;
    }

    if (t % ptr->delay)
        return 0;

    // clear the LED string
    for (uint i = ptr->first; i < ptr->last; i++)
        Pixels[i] = BLACK;

    // set every third LED to color
    if (ptr->dir > 0)
    {
        // forward
        for (uint i = ptr->first + ptr->pos; i < ptr->last; i += 3)
        {
            Pixels[i] = ColorTable[ptr->r];
        }   // for
    }
    else
    {
        // backward
        for (uint i = ptr->last - ptr->pos; i >= ptr->first; i -= 3)
        {
            Pixels[i] = ColorTable[ptr->r];
        }   // for
    }

    ptr->pos++;
    ptr->pos %= 3;
    return 1;     
}   //  actionChaser

// A single spot moving back and forth. Top Chamber never changes color (always red).
uint actionCylonEye(LED_STR_T *ptr, int t)
{
    if (ptr != Leds + 3)
    {
        ptr->cctimer++;
        if (ptr->cctimer >= 500)
        {
            ptr->cctimer = 0;
            ptr->r++;
            if (ptr->r >= MAXCOLORS)
                ptr->r = 0;
        }
    }

    if (t % ptr->delay)
        return 0;

    // clear the LED string
    for (uint i = ptr->first; i <= ptr->last; i++)
        Pixels[i] = BLACK;

    Pixels[ptr->pos] = ColorTable[ptr->r];
    
    ptr->pos += ptr->dir;
    if (ptr->pos >= ptr->last)
    {
        ptr->dir = -1;
        ptr->pos = ptr->last;
    }
    else if (ptr->pos <= ptr->first)
    {
        ptr->dir = 1;     
        ptr->pos = ptr->first;
    }

    return 1;
}   //  actionCylonEye

// A single spot moving up on the outside to center
uint actionBubbles(LED_STR_T *ptr, int t)
{
    ptr->cctimer++;
    if (ptr->cctimer >= 500)
    {
        ptr->cctimer = 0;
        ptr->r++;
        if (ptr->r >= MAXCOLORS)
            ptr->r = 0;
    }

    if (t % ptr->delay)
        return 0;

    // clear the LED string
    for (uint i = ptr->first; i <= ptr->last; i++)
        Pixels[i] = BLACK;

    // 
    Pixels[ptr->first + ptr->pos] = ColorTable[ptr->r];
    Pixels[ptr->last  - ptr->pos] = ColorTable[ptr->r];
    
    ptr->pos++;
    ptr->pos %= ptr->g;

    return 1;
}   //  actionBubbles

uint actionFadeTo(LED_STR_T *ptr, int t)
{
    if (t % ptr->delay)
        return 0;

    for (int i = ptr->first; i < ptr->last; i++)
    {
        Pixels[i] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }   //  for each pixel

    if (ptr->dir > 0)
    {
        ptr->pos++;
        ptr->b++;
        if (255 == ptr->pos)
        {
            puts("Max\n");
            ptr->dir *= -1;
        }
    }
    else
    {
        ptr->pos--;
        ptr->b--;
        if (32 == ptr->pos)
        {
            puts("Min\n");
            ptr->dir *= -1;
        }
    }

    return 1;
}   //  actionFadeTo

// changes color when it fades to low end.
uint actionFade(LED_STR_T *ptr, int t)
{
    if (t % ptr->delay)
        return 0;

    for (int i = ptr->first; i < ptr->last; i++)
    {
        Pixels[i] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }   //  for each pixel

    // RGB values are inremented/decremented as pos counts up to 255 or down to 32 
    if (ptr->dir > 0)
    {
        ptr->pos++;
        if (ptr->x & 0x01)
            ptr->b++;
        if (ptr->x & 0x02)
            ptr->r++;
        if (ptr->x & 0x04)
            ptr->g++;
            
        if (255 == ptr->pos)
        {
            ptr->dir *= -1;
        }
    }
    else
    {
        ptr->pos--;
        if (ptr->x & 0x01)
            ptr->b--;
        if (ptr->x & 0x02)
            ptr->r--;
        if (ptr->x & 0x04)
            ptr->g--;

        if (32 == ptr->pos)
        {
            ptr->dir *= -1;
            ptr->x++;
            if (ptr->x > 7)
                ptr->x = 0x01;
        }
    }

    return 1;
}   //  actionFade

uint actionRandom(LED_STR_T *ptr, int t)
{
    if (t % ptr->delay)
        return 0;

    for (int i = ptr->first; i < ptr->last; i++)
    {
        Pixels[i] = (Gamma8[rand() % 256] << 24 | Gamma8[rand() % 256] << 16 |
                     Gamma8[rand() % 256] << 8);
    }   //  for each pixel

    return 1;
}   //  actionRandom

uint actionSparkle(LED_STR_T *ptr, int t)
{
    ptr->cctimer++;
    if (ptr->cctimer >= 500)
    {
        ptr->cctimer = 0;
        ptr->r++;
        ptr->r %= 8; 
    }

    if (t % ptr->delay)
        return 0;

    for (int i = ptr->first; i < ptr->last; i++)
    {
///        Pixels[i] = (rand() % 16) ? BLACK : ugrb_u32(ptr->r, ptr->g, ptr->b);
///        Pixels[i] = (rand() % 8) ? BLACK : ugrb_u32(ptr->r, ptr->g, ptr->b);
///        Pixels[i] = (rand() % 8) ? BLACK : ColorTable[1 + rand() % 7];
        if (0 == ptr->r)
        {
            // random color
            Pixels[i] = (rand() % 8) ? BLACK : ColorTable[1 + rand() % 7];
        }
        else
        {
            // all same color
            Pixels[i] = (rand() % 8) ? BLACK : ColorTable[ptr->r];
        }
    }   //  for each pixel

    return 1;
}   //  actionSparkle

uint actionSprites(LED_STR_T *ptr, int t)
{
    uint    j = ptr->pos;

    // ptr->x == 0 indicates the sprite is not used (no pixels)
    if (0 == ptr->x)
        return 0;

    if (t % ptr->delay)
        return 0;

    // erase current sprite if set
    if (ptr->g)
    {     
        for (int i = 0; i < ptr->x; i++)
        {
            Pixels[j++] ^= ColorTable[ptr->r];
            if (j >= ptr->last)
                j = ptr->first;
        }   //  for
    }

    // check for end of strip
    if (ptr->first == ptr->pos)
    {
        puts("first pos ");
        ptr->cctimer++;
        if (ptr->cctimer >= 5)
        {
            // random color change
            ptr->cctimer = 0;
            printf("Color: %d\n", ptr->r);
            ptr->r = rand() % NumColors;
            printf("New Color: %d\n", ptr->r);
        }
    }

    // move the sprite position
    ptr->pos += ptr->dir;

    // keep it in bounds
    if (ptr->pos >= ptr->last)
        ptr->pos = (ptr->dir > 0) ? ptr->first : ptr->last - 1;

    // add sprite in new position, ptr->x has the sprite size in pixels
    j = ptr->pos;
    for (int i = 0; i < ptr->x; i++)
    {
        Pixels[j++] ^= ColorTable[ptr->r];
        if (j >= ptr->last)
            j = ptr->first;
    }   //  for

    ptr->g = 1;
    return 1;
}   //  actionSprites

uint actionProgessive(LED_STR_T *ptr, int t)
{
    if (0 == ptr->delay)
        return 0;

    if (t % ptr->delay)
        return 0;

    Pixels[ptr->pos] = ColorTable[ptr->r];
    ptr->pos++;
    if (ptr->pos >= ptr->last)
    {
        ptr->pos = ptr->first;
        ptr->r++;
        if (ptr->r >= MAXCOLORS - 1)
            ptr->r = 0;
    }
    return 1;
}   //  actionProgressive

uint actionColors(LED_STR_T *ptr, int t)
{
    if (0 == ptr->delay)
        return 0;

    if (t % ptr->delay)
        return 0;

    Pixels[ptr->pos] = ColorTable[ptr->r];
    ptr->pos++;
    if (ptr->pos >= ptr->last)
    {
        ptr->pos = ptr->first;
//        ptr->r++;
//        if (ptr->r >= MAXCOLORS - 1)
//            ptr->r = 0;
    }
    return 1;
}   //  actionColors

// Fade the LED strip according to music frequency bands from MSGEQ7 chip.
// The three lowest bands are combined to drive the outer pipe.
// The three highest bands are combined to drive the inner pipe.
// The three middle bands are combined to drive the middle pipe.
// The middle band drives the top chamber
uint actionMsgeq7FadeCombo(LED_STR_T *ptr, int t)
{
    // only uses the first control block
    if (0 == ptr->delay)
        return 0;

    // combine the three lowest bands to drive the outer LED strip segments
    int i = 0;
    ptr->r = Data[i++] / 16;      // scale to fit
    ptr->g = Data[i++] / 16;      // scale to fit
    ptr->b = Data[i++] / 16;      // scale to fit
    for (int j = 0; j < 25; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    // combine three highest bands to drive the inner pipe
    i = 4; 
    ptr->r = Data[i++] / 16;      // scale to fit
    ptr->g = Data[i++] / 16;      // scale to fit
    ptr->b = Data[i++] / 16;      // scale to fit
    for (int j = 25; j < 48; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    // combine three middle bands to drive the middle pipe
    i = 2;
    ptr->r = Data[i++] / 16;      // scale to fit
    ptr->g = Data[i++] / 16;      // scale to fit
    ptr->b = Data[i++] / 16;      // scale to fit
    for (int j = 48; j < 58; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    // top chamber uses the middle band only
    i = 3;
    ptr->g = 0;
    ptr->b = Data[i] / 16;      // scale to fit
    ptr->r = 0;
    for (int j = 58; j < 71; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    return 1;
}   //  actionMsgeq7FadeCombo

// Fade the LED strip according to music frequency bands from MSGEQ7 chip.
// Each LED pipe is divided in half to yield six segments. The left three
// segmengs are driven by the three lowest bands. Thr right three segments
// are driven, inside out, by the three highest bands. The top chamber is
// driven by the middle band.
uint actionMsgeq7FadeAll(LED_STR_T *ptr, int t)
{
    // only uses the first control block
    if (0 == ptr->delay)
        return 0;

    // use the three lowest bands to drive 3 LED strip segments
    // red
    int i = 0;
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->g = 0;
    ptr->b = 0;
    for (int j = 0; j < 13; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }
    // green
    i = 1; 
    ptr->g = Data[i] / 16;      // scale to fit
    ptr->r = 0;
    ptr->b = 0;
    for (int j = 25; j < 36; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }
    // blue
    i = 2;
    ptr->r = 0;
    ptr->g = 0;
    ptr->b = Data[i++] / 16;      // scale to fit
    for (int j = 53; j < 58; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    // top chamber
    // white
    i = 3;
    ptr->g = Data[i] / 16;      // scale to fit
    ptr->b = Data[i] / 16;      // scale to fit
    ptr->r = Data[i] / 16;      // scale to fit
    for (int j = 58; j < 71; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    // three highest bands drive 3 LED segments
    // orange
     i = 4; 
    ptr->g = Data[i] / 112;     // scale to fit
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->b = 0;
    for (int j = 48; j < 53; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }
    // purple
    i = 5; 
    ptr->b = Data[i] / 16;      // scale to fit
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->g = 0;
    for (int j = 37; j < 48; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    i = 6;
    // yellow
    ptr->g = Data[i] / 16;      // scale to fit
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->b = 0;
    for (int j = 13; j < 25; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    return 1;
}   //  actionMsgeq7FadeAll

// Fade the LED strip according to music frequency bands from MSGEQ7 chip.
// the two lowest and two highest bands drive the outer LEDs. the three middle
// bands are combined to drive the middle LEDs and the top chamber LEDs.
uint actionMsgeq7FadeNew(LED_STR_T *ptr, int t)
{
    // only uses the first control block
    if (0 == ptr->delay)
        return 0;

    // use the two lowest bands to drive 2 LED strip segments
    int i = 0;
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->g = 0;
    ptr->b = 0;
    for (int j = 0; j < 13; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    i = 1; 
    ptr->g = Data[i] / 16;      // scale to fit
    ptr->r = 0;
    ptr->b = 0;
    for (int j = 25; j < 36; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    // middle LED pipe uses a mix of the three middle bands
    // band 2 -> red
    // band 3 -> green
    // band 4 -> blue
    i = 2;
    ptr->r = Data[i++] / 16;      // scale to fit
    ptr->g = Data[i++] / 16;      // scale to fit
    ptr->b = Data[i++] / 16;      // scale to fit
    for (int j = 48; j < 58; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    i = 5; 
    ptr->g = Data[i] / 16;      // scale to fit
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->b = 0;
    for (int j = 37; j < 48; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    i = 6; 
    ptr->g = 0;
    ptr->r = 0;
    ptr->b = Data[i] / 16;      // scale to fit
    for (int j = 13; j < 25; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    // top chamber uses a mix of three bands
    // band 2 -> green
    // band 3 -> blue
    // band 4 -> red
    i = 2;
    ptr->g = Data[i++] / 16;      // scale to fit
    ptr->b = Data[i++] / 16;      // scale to fit
    ptr->r = Data[i]   / 16;      // scale to fit
    for (int j = 58; j < 71; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }
    return 1;
}   //  actionMsgeq7FadeNew

// Fade the LED strip according to music frequency bands from MSGEQ7 chip.
uint actionMsgeq7Fade(LED_STR_T *ptr, int t)
{
    if (0 == ptr->delay)
        return 0;

//    if (t % ptr->delay)
//        return 0;

    // use the 5 middle bands to drive 5 LED strip segments
    int i = 1;
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->g = 0;
    ptr->b = 0;
    for (int j = 0; j < 12; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    i++; 
    ptr->g = Data[i] / 16;      // scale to fit
    ptr->r = 0;
    ptr->b = 0;
    for (int j = 25; j < 36; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    i++; 
    ptr->b= Data[i] / 16;      // scale to fit
    ptr->r = 0;
    ptr->g = 0;
    for (int j = 48; j < 58; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    i++; 
    ptr->g = Data[i] / 16;      // scale to fit
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->b = 0;
    for (int j = 37; j < 48; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    i++; 
    ptr->g = Data[i] / 16;      // scale to fit
    ptr->r = 0;
    ptr->b = Data[i] / 16;      // scale to fit
    for (int j = 13; j < 25; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    // top chamber uses a mix of three bands
    i = 2;
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->g = Data[i + 2] / 16;      // scale to fit
    ptr->b = Data[i + 4] / 16;      // scale to fit
    for (int j = 58; j < 71; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }
    return 1;
}   //  actionMsgeq7Fade

// Frequency data determine how many LEDs are lit for five of the seven bands
uint actionMsgeq7(LED_STR_T *ptr, int t)
{
    uint scale;

    if (0 == ptr->delay)
        return 0;

//    if (t % ptr->delay)
//        return 0;

    // black out all pixels
    fillPixels(BLACK);

    // use the 5 middle bands to drive 5 LED strip segments
    int i = 1;
    scale = Data[i] / (4096 / 13);      // scale to fit
    for (int j = 0; j < scale; j++)
    {
        Pixels[j] = ColorTable[0];
    }

    i++; 
    scale = Data[i] / (4096 / 11);      // scale to fit
    for (int j = 25; j < scale + 25; j++)
    {
        Pixels[j] = ColorTable[1];
    }

    i++; 
    scale= Data[i] / (4096 / 10);      // scale to fit
    for (int j = 48; j < scale + 48; j++)
    {
        Pixels[j] = ColorTable[2];
    }

    i++; 
    scale = Data[i] / (4096 / 11);      // scale to fit
    for (int j = 47; j >= 47 - scale; j--)
    {
        Pixels[j] = ColorTable[3];
    }

    i++; 
    scale = Data[i] / (4096 / 13);      // scale to fit
    for (int j = 24; j >= 24 - scale; j--)
    {
        Pixels[j] = ColorTable[4];
    }

    // top chamber uses a mix of three bands
    i = 2;
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->g = Data[i + 2] / 16;      // scale to fit
    ptr->b = Data[i + 4] / 16;      // scale to fit
    for (int j = 58; j < 71; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }
    return 1;
}   //  actionMsgeq7

uint actionMsgeq7Fade1(LED_STR_T *ptr, int t)
{
    if (0 == ptr->delay)
        return 0;

//    if (t % ptr->delay)
//        return 0;

//    for(int i = 0; i < 8; i++)
    int i = 1;
    printf("%u, %0X, %u\n", Data[i], Data[i], Data[i] / 16);
    ptr->r = Data[i] / 16;      // scale to fit
    ptr->g = Data[i + 2] / 16;      // scale to fit
    ptr->b = Data[i + 4] / 16;      // scale to fit
    for (int j = 0; j < 12; j++)
    {
        Pixels[j] = gammaCorrection(ptr->r, ptr->g, ptr->b);
    }

    return 1;
}   //  actionMsgeq7Fade

// define a pointer to an action function
typedef uint (*Action)(LED_STR_T *ptr, int t);

// array of action functions
Action ActionTable[] =
    {actionChaser, actionCylonEye, actionBubbles, actionFade, actionRandom, actionSparkle,
     actionProgessive, actionSprites, actionMsgeq7Fade, actionMsgeq7, actionMsgeq7FadeCombo,
     actionMsgeq7FadeAll, actionMsgeq7FadeNew
     //, actionFadeTo, actionColors
    };


//***** LED String Action *****
void changeAction(uint step)
{
    if (NewAction)
    {
        NewAction = false;
        // advance the pattern & keep it in range
        Pat += step;
        Pat %= count_of(ActionTable);

        Dir = (rand() >> 30) & 1 ? 1 : -1;

        // black out all pixels
        fillPixels(BLACK);

        // do any required pattern setup
        switch(Pat)
        {
            case 0: // actionChaser initialization
                Leds[0].delay = 8;          // 50mS
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].cctimer = 0;        // color change timer
                Leds[0].dir = 1;            // forward
                Leds[0].r = 1;              // initial color index
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 8;          // 50mS
                Leds[1].pos = 0;
                Leds[1].first = 25;
                Leds[1].last = 48;
                Leds[1].cctimer = 125;
                Leds[1].dir = -1;           // backward
                Leds[1].r = 2;
                Leds[1].g = 0;
                Leds[1].b = 0;

                Leds[2].delay = 8;          // 50mS
                Leds[2].pos = 0;
                Leds[2].first = 48;
                Leds[2].last = 58;
                Leds[2].cctimer = 250;             // step
                Leds[2].dir = 1;            // forward
                Leds[2].r = 3;
                Leds[2].g = 0;
                Leds[2].b = 0;

                Leds[3].delay = 8;          // 50mS
                Leds[3].pos = 0;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].cctimer = 375 ;
                Leds[3].dir = -1;           // backward
                Leds[3].r = 5;
                Leds[3].g = 0;
                Leds[3].b = 0;
                break;
                
            case 1: // actionCylonEye initialization
                Leds[0].delay = 5;          // 50mS
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 24;
                Leds[0].cctimer = 0;        // color change timer
                Leds[0].dir = 1;            // forward
                Leds[0].r = Red;
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 5;          // 50mS
                Leds[1].pos = 25;
                Leds[1].first = 25;
                Leds[1].last = 47;
                Leds[1].cctimer = 125;      // color change timer
                Leds[1].dir = -1;           // backward
                Leds[1].r = Blue;
                Leds[1].g = 0;
                Leds[1].b = 0;

                Leds[2].delay = 10;         // 100mS
                Leds[2].pos = 48;
                Leds[2].first = 48;
                Leds[2].last = 57;
                Leds[2].cctimer = 250;      // color change timer
                Leds[2].dir = 1;            // forward
                Leds[2].r = Green;
                Leds[2].g = 0;
                Leds[2].b = 0;

                Leds[3].delay = 10;         // 100mS
                Leds[3].pos = 66;
                Leds[3].first = 66;
                Leds[3].last = 70;
                Leds[3].cctimer = 375;      // color change timer
                Leds[3].dir = -1;           // backward
                Leds[3].r = Red;
                Leds[3].g = 0;
                Leds[3].b = 0;
                break;
                
            case 2: // bubbles initialization
                Leds[0].delay = 5;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 24;
                Leds[0].cctimer = 125;
                Leds[0].dir = 1;            // forward
                Leds[0].r = Red;
                Leds[0].g = 12;
                Leds[0].b = 0;

                Leds[1].delay = 5;          // 50mS
                Leds[1].pos = 0;
                Leds[1].first = 25;
                Leds[1].last = 47;
                Leds[1].cctimer = 250;
                Leds[1].dir = 1;
                Leds[1].r = Blue;
                Leds[1].g = 11;
                Leds[1].b = 0;

                Leds[2].delay = 10;          // 50mS
                Leds[2].pos = 0;
                Leds[2].first = 48;
                Leds[2].last = 57;
                Leds[2].cctimer = 375;
                Leds[2].dir = 1;            // forward
                Leds[2].r = Green;
                Leds[2].g = 5;
                Leds[2].b = 0;

                Leds[3].delay = 5 ;         // 50mS
                Leds[3].pos = 0;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].cctimer = 375;
                Leds[3].dir = 1;
                Leds[3].r = Orange;
                Leds[3].g = 7;
                Leds[3].b = 0;
                break;
            case 3: // fade initialization 
                Leds[0].delay = 1;
                Leds[0].pos = 1;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].cctimer = 0;
                Leds[0].x = 0x01;
                Leds[0].dir = 1;          // forward
                Leds[0].r = 0;
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 1;          // 500mS
                Leds[1].pos = 1;
                Leds[1].first = 25;
                Leds[1].last = 48;
                Leds[1].cctimer = 0;
                Leds[1].x = 0x02;
                Leds[1].dir = 1;
                Leds[1].r = 0;
                Leds[1].g = 0;
                Leds[1].b = 0;

                Leds[2].delay = 1;          // 500mS
                Leds[2].pos = 1;
                Leds[2].first = 48;
                Leds[2].last = 58;
                Leds[2].cctimer = 0;
                Leds[2].x = 0x04;
                Leds[2].dir = 1;            // forward
                Leds[2].r = 0;
                Leds[2].g = 0;
                Leds[2].b = 0;

                Leds[3].delay = 1 ;         // 500mS
                Leds[3].pos = 1;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].cctimer = 0;
                Leds[3].x = 0x03;
                Leds[3].dir = 1;
                Leds[3].r = 0;
                Leds[3].g = 0;
                Leds[3].b = 0;
                break;
            case 4: //  Random inialization 
                Leds[0].delay = 10;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].dir = 1; // forward

                Leds[1].delay = 10;
                Leds[1].pos = 25;
                Leds[1].first = 25;
                Leds[1].last = 48;
                Leds[1].dir = 1;

                Leds[2].delay = 10;
                Leds[2].pos = 48;
                Leds[2].first = 48;
                Leds[2].last = 58;
                Leds[2].dir = 1;

                // use only the 8 leds on the arch
                Leds[3].delay = 10;
                Leds[3].pos = 58;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].dir = 1;
               break;
            case 5: // sparkle initialization
                puts("Sparkle");
                Leds[0].delay = 8;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].dir = 1; // every third LED
                Leds[0].r = 1;
                Leds[0].g = 0;
                Leds[0].b = 0;
                Leds[0].cctimer = 0;

                Leds[1].delay = 8;
                Leds[1].pos = 25;
                Leds[1].first = 25;
                Leds[1].last = 48;
                Leds[1].dir = 1;
                Leds[1].r = 3;
                Leds[1].g = 0;
                Leds[1].b = 255;
                Leds[1].cctimer = 64;

                Leds[2].delay = 8;
                Leds[2].pos = 48;
                Leds[2].first = 48;
                Leds[2].last = 58;
                Leds[2].dir = 1;
                Leds[2].r = 6;
                Leds[2].g = 0;
                Leds[2].b = 0;
                Leds[2].cctimer = 128;

                // use only the 8 leds on the arch
                Leds[3].delay = 8;
                Leds[3].pos = 58;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].dir = 1;
                Leds[3].r = 5;
                Leds[3].g = 0;
                Leds[3].b = 255;
                Leds[3].cctimer = 32;
               break;
            case 6: // Progessive initialization
                puts("Progessive");
                Leds[0].delay = 5;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 71;
                Leds[0].dir = 1;
                Leds[0].r = 7;
                Leds[0].g = 0;
                Leds[0].b = 0;
                Leds[0].cctimer = 0;

                Leds[1].delay = 0;
                Leds[1].pos = 25;
                Leds[1].first = 25;
                Leds[1].last = 48;
                Leds[1].dir = 1;
                Leds[1].r = 3;
                Leds[1].g = 0;
                Leds[1].b = 255;
                Leds[1].cctimer = 64;

                Leds[2].delay = 0;
                Leds[2].pos = 48;
                Leds[2].first = 48;
                Leds[2].last = 58;
                Leds[2].dir = 1;
                Leds[2].r = 6;
                Leds[2].g = 0;
                Leds[2].b = 0;
                Leds[2].cctimer = 128;

                Leds[3].delay = 0;
                Leds[3].pos = 58;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].dir = 1;
                Leds[3].r = 5;
                Leds[3].g = 0;
                Leds[3].b = 255;
                Leds[3].cctimer = 32;
               break;
            case 7: // sprites initialization
                puts("Sprites");
                Leds[0].delay = 19;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 71;
                Leds[0].dir = 1;
                Leds[0].x = 5;
                Leds[0].cctimer = 0;
                Leds[0].r = Red;    // red
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 11;
                Leds[1].pos = 25;
                Leds[1].first = 0;
                Leds[1].last = 71;
                Leds[1].dir = -1;
                Leds[1].x = 3;
                Leds[1].cctimer = 0;
                Leds[1].r = Blue;    // blue
                Leds[1].g = 0;
                Leds[1].b = 0;

                Leds[2].delay = 7;
                Leds[2].pos = 48;
                Leds[2].first = 0;
                Leds[2].last = 71;
                Leds[2].dir = 1;
                Leds[2].x = 6;
                Leds[2].cctimer = 0;
                Leds[2].r = Green;    // green
                Leds[2].g = 0;
                Leds[2].b = 0;

                Leds[3].delay = 5;
                Leds[3].pos = 58;
                Leds[3].first = 0;
                Leds[3].last = 71;
                Leds[3].dir = -1;
                Leds[3].cctimer = 0;
                Leds[3].x = 4;
                Leds[3].r = Purple;    // purple
                Leds[3].g = 0;
                Leds[3].b = 0;
               break;
            case 8: // Msgeq7Fade initialization 
                Leds[0].delay = 1;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].cctimer = 0;
                Leds[0].x = 0;
                Leds[0].dir = 1;          // forward
                Leds[0].r = 0;            // color table index
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 0;          // 500mS
                Leds[1].pos = 25;
                Leds[1].first = 25;
                Leds[1].last = 48;
                Leds[1].cctimer = 0;
                Leds[1].x = 0;
                Leds[1].dir = 1;
                Leds[1].r = 0;
                Leds[1].g = 0;
                Leds[1].b = 0;

                Leds[2].delay = 0;          // 500mS
                Leds[2].pos = 48;
                Leds[2].first = 48;
                Leds[2].last = 58;
                Leds[2].cctimer = 0;
                Leds[2].x = 0;
                Leds[2].dir = 1;            // forward
                Leds[2].r = 0;
                Leds[2].g = 0;
                Leds[2].b = 0;

                Leds[3].delay = 0 ;         // 500mS
                Leds[3].pos = 58;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].cctimer = 8;
                Leds[3].x = 0;
                Leds[3].dir = 1;
                Leds[3].r = 0;
                Leds[3].g = 0;
                Leds[3].b = 0;
                break;
            case 9: // Msgeq7 initialization 
                Leds[0].delay = 1;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].cctimer = 0;
                Leds[0].x = 0;
                Leds[0].dir = 1;          // forward
                Leds[0].r = 0;            // color table index
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 0;          // 500mS
                Leds[1].pos = 25;
                Leds[1].first = 25;
                Leds[1].last = 48;
                Leds[1].cctimer = 0;
                Leds[1].x = 0;
                Leds[1].dir = 1;
                Leds[1].r = 0;
                Leds[1].g = 0;
                Leds[1].b = 0;

                Leds[2].delay = 0;          // 500mS
                Leds[2].pos = 48;
                Leds[2].first = 48;
                Leds[2].last = 58;
                Leds[2].cctimer = 0;
                Leds[2].x = 0;
                Leds[2].dir = 1;            // forward
                Leds[2].r = 0;
                Leds[2].g = 0;
                Leds[2].b = 0;

                Leds[3].delay = 0 ;         // 500mS
                Leds[3].pos = 58;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].cctimer = 8;
                Leds[3].x = 0;
                Leds[3].dir = 1;
                Leds[3].r = 0;
                Leds[3].g = 0;
                Leds[3].b = 0;
                break;
            case 10: // Msgeq7FadeCombo initialization 
                Leds[0].delay = 1;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].cctimer = 0;
                Leds[0].x = 0;
                Leds[0].dir = 1;          // forward
                Leds[0].r = 0;            // color table index
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 0;      // not used
                Leds[2].delay = 0;      // not used
                Leds[3].delay = 0;      // not used
                break;
            case 11: // Msgeq7FadeAll initialization 
                Leds[0].delay = 1;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].cctimer = 0;
                Leds[0].x = 0;
                Leds[0].dir = 1;          // forward
                Leds[0].r = 0;            // color table index
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 0;      // not used
                Leds[2].delay = 0;      // not used
                Leds[3].delay = 0;      // not used
                break;
            case 12: // Msgeq7FadeNew initialization 
                Leds[0].delay = 1;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].cctimer = 0;
                Leds[0].x = 0;
                Leds[0].dir = 1;          // forward
                Leds[0].r = 0;            // color table index
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 0;      // not used
                Leds[2].delay = 0;      // not used
                Leds[3].delay = 0;      // not used
                break;

            case 25: // fadeto initialization 
                Leds[0].delay = 0;
                Leds[0].pos = 1;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].cctimer = 24;
                Leds[0].dir = 1;          // forward
                Leds[0].r = 0;
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 0;          // 500mS
                Leds[1].pos = 1;
                Leds[1].first = 25;
                Leds[1].last = 48;
                Leds[1].cctimer = 16;
                Leds[1].dir = 1;
                Leds[1].r = 0;
                Leds[1].g = 0;
                Leds[1].b = 0;

                Leds[2].delay = 0;          // 500mS
                Leds[2].pos = 1;
                Leds[2].first = 48;
                Leds[2].last = 58;
                Leds[2].cctimer =8;
                Leds[2].dir = 1;            // forward
                Leds[2].r = 0;
                Leds[2].g = 0;
                Leds[2].b = 0;

                Leds[3].delay = 0 ;         // 500mS
                Leds[3].pos = 1;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].cctimer = 8;
                Leds[3].dir = 1;
                Leds[3].r = 0;
                Leds[3].g = 0;
                Leds[3].b = 0;
                break;
            case 26: // color test initialization 
                Leds[0].delay = 20;
                Leds[0].pos = 0;
                Leds[0].first = 0;
                Leds[0].last = 25;
                Leds[0].cctimer = 0;
                Leds[0].dir = 1;            // forward
                Leds[0].r = Yellow;
                Leds[0].g = 0;
                Leds[0].b = 0;

                Leds[1].delay = 20;          // 500mS
                Leds[1].pos = 25;
                Leds[1].first = 25;
                Leds[1].last = 48;
                Leds[1].cctimer = 0;
                Leds[1].dir = 1;
                Leds[1].r = LtGreen;
                Leds[1].g = 0;
                Leds[1].b = 0;

                Leds[2].delay = 20;          // 500mS
                Leds[2].pos = 48;
                Leds[2].first = 48;
                Leds[2].last = 58;
                Leds[2].cctimer = 0;
                Leds[2].dir = 1;            // forward
                Leds[2].r = Green;          // green
                Leds[2].g = 0;
                Leds[2].b = 0;

                Leds[3].delay = 20 ;         // 500mS
                Leds[3].pos = 58;
                Leds[3].first = 58;
                Leds[3].last = 71;
                Leds[3].cctimer = 0;
                Leds[3].dir = 1;
                Leds[3].r = Purple;          // purple
                Leds[3].g = 0;
                Leds[3].b = 0;
                break;
        }   //  switch
    }
}   //  changePattern

void next_action_event_handler(uint gpio, uint32_t events)
{
    // events are a bit map of the irq cause
    if (events & GPIO_IRQ_EDGE_RISE)
    {
        // next action pin raised
        puts("Next Action");
        NewAction = true;
    }
    else if (events & GPIO_IRQ_EDGE_FALL)
    {
        // next action pin dropped
    }
}   //  next_action_event_handler


// LED repeating timer callback. This is the basis of all LED action timing.
bool led_repeating_timer_cb(struct repeating_timer *t)
{
    static uint d = 0;
    static bool flag = false;
//    int dirty = 0;

    d += Dir;

    // blink the built-in LED every 100mS
    if (0 == d % 10)
    {
        gpio_put(BUILTIN_LED_PIN, flag);
        flag = (flag) ? false : true;
    }

    DoAction = true;
    return true;
}   //  led_repeating_timer_cb

// this is invoked when the DMA transfer to the LED PIO is finished.
void led_dma_complete_handler(void)
{
///    puts("irq");
    // clear the IRQ flag if it is our interrupt
    if (dma_hw->ints0 & LED_DMA_CHANNEL_MASK) 
    { // are we called for our DMA channel?
        dma_hw->ints0 = LED_DMA_CHANNEL_MASK; // clear IRQ
///        puts("dma irq");
    }
}   //  led_dma_complete_handler

//===== main forever loop =====
int main() 
{
    int t = 0;

    // set_sys_clock_48();
    stdio_init_all();
    printf("JukeBox LEDs, using pin %d\n", WS2812_PIN);
    printf("Pico ready\n");

    // setup GPIO output pins
    gpio_init_mask(OUTMASK);
    gpio_set_dir_out_masked(OUTMASK);

    gpio_put(BUILTIN_LED_PIN, false);
    gpio_put(STB_PIN, false);

    // setup GPIO input pins
    gpio_init(NEXT_ACTION_PIN);
    gpio_set_input_enabled(NEXT_ACTION_PIN, true);      // enable input pin
    gpio_set_dir(NEXT_ACTION_PIN, false);               // input pin
    gpio_pull_down(NEXT_ACTION_PIN);                    // add pull down
 //   gpio_set_irq_enabled(NEXT_ACTION_PIN, SW_MASK, true);
    gpio_set_irq_enabled_with_callback(NEXT_ACTION_PIN, SW_MASK, true, &next_action_event_handler);

    gpio_init(LEDS_DISABLE_PIN);
    gpio_set_input_enabled(LEDS_DISABLE_PIN, true);     // enable input pin
    gpio_set_dir(LEDS_DISABLE_PIN, false);              // input pin
    gpio_pull_down(LEDS_DISABLE_PIN);                   // add pull down

    // Initialise UART 0
    uart_init(uart0, BAUDRATE);

    // Set the GPIO pin mux to the UART - 0 is TX, 1 is RX
    gpio_set_function(0, GPIO_FUNC_UART);
    gpio_set_function(1, GPIO_FUNC_UART);

    //===== Setup DMA, PIO & Timer for driving the LED strip =====
    // The DMA must be setup before the PIO starts and the PIO must be
    // ready before the repeating timer starts.

    // Use PIO0.SM0 for driving the LED string.
    PIO  pio = pio0;
    uint sm  = 0;

    //----- DMA Setup -----
    // Get a free channel, panic() if there are none
//    Led_Dma_Channel = dma_claim_unused_channel(true);
    dma_channel_claim(LED_DMA_CHANNEL);
    // 32 bit transfers. Source address (Pixels array) increments after each
    // transfer, destination does not change (PIO FIFO).
    // No DREQ is selected, so the DMA transfers as fast as it can.
    dma_channel_config dcc = dma_channel_get_default_config(LED_DMA_CHANNEL);
    channel_config_set_transfer_data_size(&dcc, DMA_SIZE_32);
    channel_config_set_dreq(&dcc, pio_get_dreq(pio, sm, true));               // enable PIO throttling of DMA transfers
    channel_config_set_read_increment(&dcc, true);
    channel_config_set_write_increment(&dcc, false);
    
    dma_channel_configure(
        LED_DMA_CHANNEL,    // Channel to be configured
        &dcc,               // The configuration we just created
        &pio->txf[sm],      // The initial write address
        Pixels,             // The initial read address
        NUM_PIXELS,         // Number of transfers; in this case each is one 32 bit word.
        false               // Do not start immediately.
    );

    // set interrupt handler for DMA transfer complete interrupt
    irq_set_exclusive_handler(LED_DMA_IRQ, led_dma_complete_handler);

    // map DMA channel to the interrupt
    dma_channel_set_irq0_enabled(LED_DMA_CHANNEL, true);

    // clear any pending IRQ
    dma_hw->ints0 = LED_DMA_CHANNEL_MASK;
 
    // enable the interrupt
    irq_set_enabled(LED_DMA_IRQ, true);

    //----- PIO Setup -----
    // Use PIO-0 for driving the LED string. The PIO is idle until we add a pixel to it's fifo.
    // Data from the fifo is auomaticly moved to the PIO's shift register & clocked out.
    uint offset = pio_add_program(pio, &ws2812_program);

    // The color scheme is GRBW. Bits are being shifted out from MSB first.
    ws2812_program_init(pio, sm, offset, WS2812_PIN, 800000, IS_RGBW);

    //===== ADC setup =====
    // setup ADC for channel 0 (GPIO26)
    adc_init();

    // Make sure GPIO is high-impedance, no pullups etc
    adc_gpio_init(ADC_PIN);
    // Select ADC input 0 (GPIO26)
    adc_select_input(0);

    //===== Hardware initialization is complete =====

    // set all LEDs to black
    fillPixels(0);
    showPixels();
    sleep_ms(500);

    // randomly select a pattern and direction
///    Pat = rand() % count_of(pattern_table);
    Dir = (rand() >> 30) & 1 ? 1 : -1;

    Pat = 8;
    NewAction = true;
    changeAction(0);

    // setup & start the LED repeating timer
    // Negative delay means we will call repeating_timer_callback, and call it again
    // 10ms later regardless of how long the callback took to execute.
    add_repeating_timer_ms(10, led_repeating_timer_cb, NULL, &LedTimer);

    uint8_t dirty = 0;
    bool    disabled = false;
    uint    d = 0;

    while (1)
    {
        if (!gpio_get(LEDS_DISABLE_PIN))
        {
            if (!disabled)
            {
                // disable LEDs, black out LEDs, do this once on leading edge
                disabled = true;
                fillPixels(0);
                showPixels();
            }
        }
        else
        {
            disabled = false;

            // collect data from MSGEQ7 chip.
            adcRead();
            // display the collected data
//            for (int i = 0; i < NUM_FREQ; i++)
//            {
//                printf("%d raw: 0x%04X\n", i, Data[i]);
//            }   //  for


            if (NewAction)
            {
                changeAction(1);    
            }

            if (DoAction)
            {
                dirty = 0;
                // run the selected action on all four virtual LED strips
                for (int i = 0; i < NUMLEDSTRIPS; i++)
                {
                    dirty += ActionTable[Pat](&Leds[i], d);
                }   //  for
        
                d += Dir;

                if (dirty)
                {
                    showPixels();
                }
            }
        }

        sleep_ms(10);
    }   //  forever loop
}   //  main
