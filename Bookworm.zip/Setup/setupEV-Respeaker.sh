#!/bin/bash
echo "Installing git"
sudo apt install git -y
echo "Installing pip3"
sudo apt install python3-pip -y
sudo apt install libglib2.0-dev -y
#echo "Installing Events"
sudo apt install python3-dev -y
sudo apt install python3-evdev
echo "Installing Respeaker bd drivers"
git clone https://github.com/HinTak/seeed-voicecard
cd seeed-voicecard
sudo ./install.sh
echo "Rebooting"
sudo reboot now

