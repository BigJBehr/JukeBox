#! /bin/bash
sudo apt install build-essential python3-dev python3-smbus -y
source /home/bigj/jukbox/bin/activate
/home/bigj/jukebox/bin/python3 -m pip install adafruit_ads1x15

