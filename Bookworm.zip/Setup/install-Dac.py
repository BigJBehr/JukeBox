#! /bin/python3
# This script edits /boot.config.txt to enable interfaces, disable audio and
# add specified DAC driver.
# You must run as sudo with DAC type; 'sudo python3 install-Dac.py PCM5102'.

# 08-01-24 - Modified to add copying of asound.conf

import subprocess
import sys

#Filename = "/home/bigj/work/config.txt"
Filename = "/boot/firmware/config.txt"

Lines = []

def uncomment():
  # uncomment SPI, I2S & I2C
  global Lines
  
  count = 3
  for i in range(0, len(Lines)):
    if count > 0:
      str = Lines[i]
      if Lines[i].startswith('#dtparam=i2c_arm=on'):
        print('Uncommented I2C')
        Lines[i] = str[1:]
        count -= 1
      if Lines[i].startswith('#dtparam=i2s=on'):
        print('Uncommented I2S')
        Lines[i] = str[1:]
        count -= 1
      if Lines[i].startswith('#dtparam=spi=on'):
        print('Uncommented SPI')
        Lines[i] = str[1:]
        count -= 1
    else:
      break
#------------------------------------------------------------------------------
  
def commentout():
  #  comment out some things
  global Lines
  
  count = 3
  for i in range(0, len(Lines)):
    if count > 0:
      str = Lines[i]
      if Lines[i].startswith('dtparam=audio=on'):
        print('Commented out audio jack')
        Lines[i] = '#' + str
        count -= 1
      if Lines[i].startswith('display_auto_detect=1'):
        print('Commented out display')
        Lines[i] = '#' + str
        count -= 1
      if Lines[i].startswith('camera_auto_detect=1'):
        print('Commented out camera')
        Lines[i] = '#' + str
        count -= 1
    else:
      break
#------------------------------------------------------------------------------
      
def killHDMIaudio():
  #  comment out some things
  global Lines
  
  print("File has " + str(len(Lines)) + " lines")
  
  for i in range(0, len(Lines)):
    if Lines[i].startswith('dtoverlay=vc4-kms-v3d'):
      print('Turned off HDMI audio')
      Lines[i] = 'dtoverlay=vc4-kms-v3d,noaudio\n'
      break
#------------------------------------------------------------------------------
  

#===== Main Program =====

# read file lines into a list then auto close
with open(Filename, "r") as f:
  Lines = f.readlines()

# enable interfaces
uncomment()

# get rid of unused/unwanted stuff
commentout()

if len(sys.argv) > 1:
  # DAC specific installs
  try:
    dac = sys.argv[1].upper()
    
    # install the specified DAC driver  
    if dac.startswith('PCM5102'):
      print('Generic DAC PCM5102')
      Lines.append('\ndtoverlay=hifiberry-dac\n')
      # enable software volumne control
      subprocess.run(['sudo cp sv_asound.conf /etc/asound.conf'], shell=True)
      
    elif dac.startswith('UDA1334'):
      print('Generic DAC UDA1334')
      Lines.append('\ndtoverlay=hifiberry-dac\n')
      # enable software volumne control
      subprocess.run(['sudo cp sv_asound.conf /etc/asound.conf'], shell=True)
      
    elif dac.startswith('PCM5122'):
      print('DAC uses I2C & I2S PCM5122')
      killHDMIaudio()
      Lines.append('\ndtoverlay=allo-boss-dac-pcm512x-audio\n')
      
    elif dac.startswith('WM8960'):
      print('DAC uses I2C & I2S WM8960; Respeaker Bd')
      print('Run; sudo bash setupEV-Respeaker.sh')
      subprocess.run(['sudo bash setupEV-Respeaker.sh'], shell=True)
      killHDMIaudio()
      
    elif dac.startswith('PCM5242'):
      print('DAC uses I2C & I2S PCM5242; IQAudio DAC+ Bd')
      # kill the HDMI audio to move PCM5242 to be card 0
      killHDMIaudio()
      Lines.append('\ndtoverlay=iqaudio-dacplus\n')
    else:
      print('Unknown DAC, no DAC installed.')
    
  except:
    print('You must specify a DAC to install, either;')
    print('PCM5102, UDA1334, PCM5122, PCM5242 or WM8960.')
    print('Installation aborted')

#for l in Lines:
#  print(l)

# rename with .bak extention  
subprocess.run(['sudo cp ' + Filename + ' ' + Filename + '.bak'], shell=True)

# save changes
# write everything to a new file
with open(Filename, "w") as f:
  f.writelines(Lines)
#------------------------------------------------------------------------------


