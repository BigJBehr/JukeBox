#! /bin/python3
# This script edits /boot.config.txt to enable interfaces, IR capture and decode.
# Also edits; /etc/rc.local, /etc/rc_maps.cfg, /etc/systemd/logind.conf.
# You must run as sudo with the GPIO pin to use for capture.
# type; 'sudo python3 install-IR.py pin=26 AirMouse.toml'.
# If no .toml file is specified then only IR capture is installed.

import subprocess
import sys
import os
import json

Lines = []

def uncomment(pin):
  # uncomment SPI, I2S, I2C and IR capture
  global Lines
    
  count = 4
  for i in range(0, len(Lines)):
    if count > 0:
      s = Lines[i]
      if s.startswith('#dtparam=i2c_arm=on'):
        print('Uncommented I2C')
        Lines[i] = s[1:]
        count -= 1
      if s.startswith('#dtparam=i2s=on'):
        print('Uncommented I2S')
        Lines[i] = s[1:]
        count -= 1
      if s.startswith('#dtparam=spi=on'):
        print('Uncommented SPI')
        Lines[i] = s[1:]
        count -= 1
      if s.find('dtoverlay=gpio-ir,') > -1:
        print('Uncommented IR')
        p = s.rfind('=')
        if p > -1:
          s = s[:p + 1] + str(pin) + '\n'
        else:
          print('Invalid statement; ' + s)
          print('Installation Aborted')
          sys.exit()
                  
        if '#' == s[0]:
          # uncomment the line 
          Lines[i] = s[1:]
        else:
          Lines[i] = s         
        count -= 1
    else:
      break
#------------------------------------------------------------------------------
# This will comment out things that are not used in headless operation  
def commentout():
  #  comment out some things
  global Lines
  
  count = 3
  for i in range(0, len(Lines)):
    if count > 0:
      str = Lines[i]
      if Lines[i].startswith('dtparam=audio=on'):
        print('Commented out audio jack')
        Lines[i] = '#' + str
        count -= 1
      if Lines[i].startswith('display_auto_detect=1'):
        print('Commented out display')
        Lines[i] = '#' + str
        count -= 1
      if Lines[i].startswith('camera_auto_detect=1'):
        print('Commented out camera')
        Lines[i] = '#' + str
        count -= 1
    else:
      break
#------------------------------------------------------------------------------
  

#===== Main Program =====

# default GPIO pin for IR capture is GPIO26
pin = 26
toml = None

# parse command line arguments
#for arg in sys.argv:  
#  if arg.startswith('pin='):
    # get GPIO pin number from the command line 
#    print(arg)
#    try:
#      pin = int(arg[4:])
#      print('Pin: ' + str(pin))
#    except:
#      print('No GPIO pin specified or invaild pin value, using default of GPIO26')
#    continue
    
#  if arg.endswith('.toml') and toml == None:
    # get path to the .toml file to use
#    toml = arg
#    print('.Toml: ' + toml)
# end for

# setup default configuration
Config = {
  "Remote": "AirMouse.toml",
  "Display": "ILI9341",
  "DAC": {"Type": "PCM5242",
          "Name": "IQaudIODAC",
         },
  "Pico": True
}

fn = 'jukebox.cfg'

# a file access error will throw an exception and switch to the default values.
if os.path.exists(fn):
  print(fn + ' exists')

  try:
    with open(fn, 'r') as fp:
      Config = json.load(fp)

  except:
    print('Unable to load configuration json file: ' + fn)
    print('Using default configuration')

else:
  print(fn + ' does not exist')
  print('Using default configuration')

print('Remote: '  + Config['Remote'])
print('Display: ' + Config['Display'])
print('DAC: '     + Config['DAC']['Type'] + ', ' + Config['DAC']['Name'])
print('Pico: '    + str(Config['Pico']))

if Config['Remote'].endswith('.toml'):
  # IR remote in use, install IR
  print('Setting up for IR Remote/n')
  toml = Config['Remote']
  
  # Edit /boot/config.txt to enable IR catpure and set the GPIO pin to use.
  #Filename = "/home/bigj/work/config.txt"
  Filename = "/boot/config.txt"

  # read file lines into a list then auto close
  with open(Filename, "r") as f:
    Lines = f.readlines()

  # enable interfaces & IR capture
  uncomment(pin)

  # get rid of unused/unwanted stuff
  #commentout()

  # rename with .bak extention  
  subprocess.run(['sudo cp ' + Filename + ' ' + Filename + '.bak'], shell=True)

  # save changes
  # write everything to a new file
  with open(Filename, "w") as f:
    f.writelines(Lines)

  print("IR capture installed")

  if toml == None:
    print('No .toml file specified. ir-keytable will not be installed.')
    sys.exit()

  # install ir-keytable. this must be done first because it creates the /etc/key_maps
  # folder
  subprocess.run(['sudo apt-get install ir-keytable -y'], shell=True)

  # copy your .toml file to /etc/key_maps
  try:
    subprocess.run(['sudo cp *.toml /etc/rc_keymaps'], shell=True)
  except:
    print('You must specify a valid .toml file!! Install aborted')
    sys.exit()
    
  # edit /etc/rc.local to load ir_keytable on startup.
  Filename = '/etc/rc.local'
  #Filename = 'work/rc.local'
  Lines.clear()
  with open(Filename, "r") as f:
    Lines = f.readlines()

  # Find the line '#By default this script does nothing.' and add the line to run
  # ir-keytable using the passed in .toml file.
  i = 0
  for i in range(0, len(Lines)):
    if Lines[i].startswith('# By default this script does nothing.'):
      Lines.insert(i + 1, ('\nsudo ir-keytable -c -w /etc/rc_keymaps/' + toml + '\n'))
      print('ir-keytable set to run on startup using ' + toml)
      break

  if i >= len(Lines):
    print('Did not find insertion point, ir-keytable will not run on startup') 
    sys.exit()
    
  # rename with .bak extention  
  subprocess.run(['sudo cp ' + Filename + ' ' + Filename + '.bak'], shell=True)

  # save changes
  # write everything to a new file
  with open(Filename, "w") as f:
    f.writelines(Lines)

  # Stop Power Button on remote from shutting down the RPi
  # read file lines into a list then auto close
  #Filename = 'work/logind.conf'
  Filename = '/etc/systemd/logind.conf'
  Lines.clear()
  with open(Filename, "r") as f:
    Lines = f.readlines()

  for i in range(0, len(Lines)):
    if Lines[i].startswith('#HandlePowerKey='):
      Lines.insert(i + 1, 'HandlePowerKey=suspend\n')
      print('Power Off deactivated')
      break

  if i >= len(Lines):
    print('Did not find insertion point, Power Key will kill RPi') 
    sys.exit()
    
  # rename with .bak extention  
  subprocess.run(['sudo cp ' + Filename + ' ' + Filename + '.bak'], shell=True)

  # save changes
  # write everything to a new file
  with open(Filename, "w") as f:
    f.writelines(Lines)


  # Force remote to be RC0.
  # read file lines into a list then auto close
  #Filename = 'work/rc_maps.cfg'
  Filename = '/etc/rc_maps.cfg'
  Lines.clear()
  with open(Filename, "r") as f:
    Lines = f.readlines()

  for i in range(0, len(Lines)):
    if Lines[i].startswith('#driver table'):
      Lines.insert(i + 1, ('*       *                        ' + toml + '\n'))
      print(toml + ' set as RC0')

  # rename with .bak extention  
  subprocess.run(['sudo cp ' + Filename + ' ' + Filename + '.bak'], shell=True)

  # save changes
  # write everything to a new file
  with open(Filename, "w") as f:
    f.writelines(Lines)

  print('IR & ir-key-table installed')

#------------------------------------------------------------------------------


