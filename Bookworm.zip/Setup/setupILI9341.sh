#! /bin/bash
source /home/jukebox/bin/activate
/home/jukebox/bin/python3 -m pip install adafruit-circuitpython-rgb-display
sudo apt install fonts-dejavu -y 
sudo apt install python3-pil -y

