#! /bin/python3
# This script edits ~/.bashrc to add 'source /home/jukebox/bin/activate'. This
# will activate the jukebox python virtual environment.
# All commands in bashrc are run when the system starts up.

import subprocess

Filename = "~/.bashrc"

StrToAdd = "source /home/jukebox/bin/activate\n"

Lines = []

# read file lines into a list
with open(Filename, "r") as f:
  Lines = f.readlines()

# add line to end of file
Lines.append(StrToAdd)

# write everything to a new file
with open(Filename, "w") as f:
  f.writelines(Lines)
  
print("Autoboot python environment activated")


