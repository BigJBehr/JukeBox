#! /bin/python3
# This script edits /etc/fstab to add mount command for my NAS with my music 
# folder (Player). Guest account is used as guest is read only and no password.
# You must run as sudo; 'sudo python3 install-Nas.py'.

import subprocess

#Filename = "/home/bigj/work/fstab"
Filename = "/etc/fstab"

# My router is setup to issue fixed IP addresses to my printers and NAS devices.
# You should do the same.
# You need to change the path to the NAS to match your system. Also need to change
# the 'username=guest' & 'password=' to match the username & password for your NAS.
StrToAdd = "\n//192.168.0.23/Shared/Player/ /home/music cifs username=guest,password=,x-systemd.automount 0 0\n"

Lines = []

# read file lines into a list
with open(Filename, "r") as f:
  Lines = f.readlines()

#for l in Lines:
#  print(l)

# rename with .bak extention  
subprocess.run(['sudo cp ' + Filename + ' ' + Filename + '.bak'], shell=True)

# add line to end of file
Lines.append(StrToAdd)

# write everything to a new file
with open(Filename, "w") as f:
  f.writelines(Lines)
  
print("NAS Automount installed")


