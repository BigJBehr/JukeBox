#! /bin/bash
source /home/bigj/jukebox/bin/activate
/home/bigj/jukebox/bin/python3 -m pip install rpi-ws281x
/home/bigj/jukebox/bin/python3 -m pip install adafruit-circuitpython-neopixel


