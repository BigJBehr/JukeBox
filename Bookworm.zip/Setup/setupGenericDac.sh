# Run this file to use softvol with a generic DAC (PCM5102 or UDA1334)
sudo mv -f sv_asound.conf /etc/asound.conf

