#! /bin/bash
sudo apt install ir-keytable -y
sudo cp *.toml /etc/rc_keymaps


