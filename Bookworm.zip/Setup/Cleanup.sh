#! /bin/bash

# cleanup after installation

sudo rm *.py
sudo rm *.conf
sudo rm *.automount
sudo rm *.sh

echo 'Cleanup Complete'

