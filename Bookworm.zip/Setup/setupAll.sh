#! /bin/bash
START=$(date +'%s')

sudo apt-get update
sudo apt-get upgrade -y

sudo apt install python3-pip -y
sudo apt install libglib2.0-dev -y
sudo apt install python3-dev -y
sudo apt install python3-evdev
sudo apt install evtest -y
sudo apt install git -y
sudo apt install fonts-dejavu -y
sudo apt install python3-pil -y
sudo apt install build-essential
sudo apt install i2c-tools -y
sudo apt install python3-smbus -y

sudo mkdir /home/music
sudo mkdir /home/usb
sudo mkdir /home/nas

sudo cp *.automount /etc/systemd/system

sudo python3 -m venv /home/jukebox
source /home/jukebox/bin/activate

python3 -m venv --system-site-packages /home/jukebox

sudo /home/jukebox/bin/python3 -m pip install sh
sudo /home/jukebox/bin/python3 -m pip install pyudev
sudo /home/jukebox/bin/python3 -m pip install pygame==2.6.1
sudo /home/jukebox/bin/python3 -m pip install pygame --upgrade
sudo /home/jukebox/bin/python3 -m pip install adafruit-circuitpython-rgb-display
sudo /home/jukebox/bin/python3 -m pip install adafruit-circuitpython-neopixel
sudo /home/jukebox/bin/python3 -m pip install rpi-ws281x
sudo /home/jukebox/bin/python3 -m pip install adafruit_circuitpython-ads1x15

#sudo mv *.sh /home/bigj/jukebox

# enable I2C and create I2c devices
sudo raspi-config nonint do_i2c 0

# disable power key to keep Pi from shutting down
sudo python3 FixPwrButton.py

# setup NAS drive to automount on boot
sudo python3 install-Nas.py

# install driver for DAC and make other changes
sudo python3 install-Dac.py

# install driver for IR Remote if needed
sudo python3 install-IR.py

END=$(date +'%s')
echo $END
echo $START
echo $((END - START))

echo "***** Rebooting *****"
sudo reboot now



